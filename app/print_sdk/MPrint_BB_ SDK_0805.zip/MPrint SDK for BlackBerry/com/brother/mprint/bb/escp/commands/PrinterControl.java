package com.brother.mprint.bb.escp.commands;

import com.brother.mprint.bb.escp.PrinterControlCommon;

/**
 * Provides ESC/P command for the printer control. <br>
 * @author naoki
 */
public class PrinterControl extends PrinterControlCommon{
}
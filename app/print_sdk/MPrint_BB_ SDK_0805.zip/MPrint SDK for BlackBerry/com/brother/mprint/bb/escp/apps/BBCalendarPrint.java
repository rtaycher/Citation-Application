package com.brother.mprint.bb.escp.apps;

import java.util.Date;
import java.util.Enumeration;
import java.util.TimeZone;

import javax.microedition.pim.EventList;
import javax.microedition.pim.PIM;
import javax.microedition.pim.PIMException;

import net.rim.blackberry.api.menuitem.ApplicationMenuItem;
import net.rim.blackberry.api.menuitem.ApplicationMenuItemRepository;
import net.rim.blackberry.api.pdap.BlackBerryEvent;
import net.rim.device.api.i18n.DateFormat;
import net.rim.device.api.i18n.SimpleDateFormat;
import net.rim.device.api.system.Bitmap;
import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.Dialog;
import net.rim.device.api.util.DateTimeUtilities;

import com.brother.mprint.bb.escp.CommunicationPort;
import com.brother.mprint.bb.escp.Connection;
import com.brother.mprint.bb.escp.commands.VerticalMovement;
import com.brother.mprint.bb.escp.sdk.BasicPrinting;

/**
 * @author oyoshida
 */
class BBCalendarPrint extends UiApplication {
    /**
     * @param args
     */
    public static void main(String[] args) {
        BBCalendarPrint theApp = new BBCalendarPrint();
        theApp.enterEventDispatcher();
    }

    private BBCalendarPrint() {
        addMenu();
    }

    private void addMenu() {
        PrintMenuInCalendar myMenuitem = new PrintMenuInCalendar(0);
        ApplicationMenuItemRepository.getInstance().addMenuItem(
                ApplicationMenuItemRepository.MENUITEM_CALENDAR, myMenuitem);
        System.exit(0);
    }
}

/**
 * @author oyoshida
 */

class PrintMenuInCalendar extends ApplicationMenuItem {
    VerticalMovement verticalMovement = new VerticalMovement();

    BasicPrinting basicPrinting = BasicPrinting.getInstance();

    Enumeration enumTheDayAllDayEvents;

    EventList eventList;

    int intEvents;

    Enumeration enumTheDayTimeEvents;

    long longOneday;

    long longTheDayMidnight;

    long longTodayMidnight;

    long longTheNextDayMidnight;

    int intDaysLater;

    /**
     * @param order
     */
    PrintMenuInCalendar(int order) {
        super(order);
    }

    public Object run(Object context) {
        SimpleDateFormat dateFormatDialog;
        Date dateCurrentTime;
        long longCurrentTime;
        String[] strDaysLater;
        dateFormatDialog = new SimpleDateFormat("E" + ", " + "M" + "/" + "d");
        intEvents = 0;
        dateCurrentTime = new Date();
        longCurrentTime = dateCurrentTime.getTime();
        longOneday = (long) DateTimeUtilities.ONEDAY;
        longTodayMidnight = longCurrentTime
                - (longCurrentTime + TimeZone.getDefault().getRawOffset())
                % longOneday;
        strDaysLater = new String[31];
        strDaysLater[0] = dateFormatDialog.formatLocal(longTodayMidnight)
                + " (Today)   ";
        strDaysLater[1] = dateFormatDialog.formatLocal(longTodayMidnight
                + longOneday)
                + " (Tomorrow)";
        for (int i = 2; i < 31; i++) {
            strDaysLater[i] = dateFormatDialog.formatLocal(longTodayMidnight
                    + i * longOneday);
        }
        Object[] o = { "Cancel", strDaysLater[0], strDaysLater[1],
                strDaysLater[2], strDaysLater[3], strDaysLater[4],
                strDaysLater[5], strDaysLater[6], strDaysLater[7],
                strDaysLater[8], strDaysLater[9], strDaysLater[10],
                strDaysLater[11], strDaysLater[12], strDaysLater[13],
                strDaysLater[14], strDaysLater[15], strDaysLater[16],
                strDaysLater[17], strDaysLater[18], strDaysLater[19],
                strDaysLater[20], strDaysLater[21], strDaysLater[22],
                strDaysLater[23], strDaysLater[24], strDaysLater[25],
                strDaysLater[26], strDaysLater[27], strDaysLater[28],
                strDaysLater[29], strDaysLater[30] };
        int[] values = { -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
                15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30 };
        Dialog d = new Dialog("Please select the day to print. ", o, values, 0,
                Bitmap.getPredefinedBitmap(Bitmap.QUESTION), (long) Dialog.LIST);
        intDaysLater = d.doModal();
        if (intDaysLater == -1) {
            return context;
        }
        longTheDayMidnight = longTodayMidnight + intDaysLater * longOneday;
        longTheNextDayMidnight = longTheDayMidnight + longOneday;
        eventList = null;
        try {
            eventList = (EventList) PIM.getInstance().openPIMList(
                    PIM.EVENT_LIST, PIM.READ_ONLY);
        } catch (PIMException pe) {
        }
        enumTheDayAllDayEvents = null;
        try {
            enumTheDayAllDayEvents = eventList.items(EventList.STARTING,
                    longTheDayMidnight + TimeZone.getDefault().getRawOffset(),
                    longTheNextDayMidnight
                            + TimeZone.getDefault().getRawOffset() - 1, false);
        } catch (PIMException pe) {
        }
        enumTheDayTimeEvents = null;
        try {
            enumTheDayTimeEvents = eventList.items(EventList.STARTING,
                    longTheDayMidnight, longTheNextDayMidnight - 1, false);
        } catch (PIMException pe) {
        }
        if (!enumTheDayAllDayEvents.hasMoreElements()
                && !enumTheDayTimeEvents.hasMoreElements()) {
            Dialog.alert("There are no appointments to print.");
        } else {
            PrintThread printThread = new PrintThread();
            printThread.start();
        }
        return context;
    }

    public String toString() {
        return "Print...";
    }

    /**
     * @author oyoshida
     */
    private class PrintThread extends Thread {
        String strTheDay;

        SimpleDateFormat dateFormatDateFull;

        SimpleDateFormat dateFormatTimeDefault;

        int intLine;

        boolean booleanFirstLine;

        PrintThread() {
            dateFormatDateFull = new SimpleDateFormat(DateFormat.DATE_FULL);
            dateFormatTimeDefault = new SimpleDateFormat(
                    DateFormat.TIME_DEFAULT);
            intLine = 0;
            strTheDay = new String(dateFormatDateFull
                    .formatLocal(longTheDayMidnight));
        }

        public void run() {
            if (basicPrinting.mpEscpInit(CommunicationPort.COMMUNICATION_PORT_BLUETOOTH, Connection.orientationSetting)) {
                basicPrinting.mpEscpPositionCtrl(0, 0);
                intLine = printEachLine("", intLine, strTheDay);
                intLine = lineOrPageFeed(intLine);
                while (enumTheDayAllDayEvents.hasMoreElements()) {
                    BlackBerryEvent event = (BlackBerryEvent) enumTheDayAllDayEvents
                            .nextElement();
                    if (eventList.isSupportedField(BlackBerryEvent.ALLDAY)) {
                        if (event.countValues(BlackBerryEvent.ALLDAY) > 0) {
                            intLine = printEachLine("All Day Event", intLine,
                                    " ");
                            if (eventList
                                    .isSupportedField(BlackBerryEvent.SUMMARY)) {
                                for (int j = 0; j < event
                                        .countValues(BlackBerryEvent.SUMMARY); ++j) {
                                    intLine = printEachLine("   Appt.: ",
                                            intLine, event.getString(
                                                    BlackBerryEvent.SUMMARY, j));
                                }
                            }
                            if (eventList
                                    .isSupportedField(BlackBerryEvent.LOCATION)) {
                                for (int j = 0; j < event
                                        .countValues(BlackBerryEvent.LOCATION); ++j) {
                                    intLine = printEachLine(
                                            "Location: ",
                                            intLine,
                                            event
                                                    .getString(
                                                            BlackBerryEvent.LOCATION,
                                                            j));
                                }
                            }
                            if (eventList
                                    .isSupportedField(BlackBerryEvent.NOTE)) {
                                for (int j = 0; j < event
                                        .countValues(BlackBerryEvent.NOTE); ++j) {
                                    intLine = printEachLine("   Notes: ",
                                            intLine, event.getString(
                                                    BlackBerryEvent.NOTE, j));
                                }
                            }
                            if (enumTheDayAllDayEvents.hasMoreElements()
                                    || enumTheDayTimeEvents.hasMoreElements()) {
                                intLine = lineOrPageFeed(intLine);
                            }
                        }
                    }
                }
                while (enumTheDayTimeEvents.hasMoreElements()) {
                    BlackBerryEvent event = (BlackBerryEvent) enumTheDayTimeEvents
                            .nextElement();
                    if (eventList.isSupportedField(BlackBerryEvent.ALLDAY)) {
                        if (event.countValues(BlackBerryEvent.ALLDAY) == 0) {
                            if (eventList
                                    .isSupportedField(BlackBerryEvent.SUMMARY)) {
                                for (int j = 0; j < event
                                        .countValues(BlackBerryEvent.SUMMARY); ++j) {
                                    intLine = printEachLine("   Appt.: ",
                                            intLine, event.getString(
                                                    BlackBerryEvent.SUMMARY, j));
                                }
                            }
                            if (eventList
                                    .isSupportedField(BlackBerryEvent.LOCATION)) {
                                for (int j = 0; j < event
                                        .countValues(BlackBerryEvent.LOCATION); ++j) {
                                    intLine = printEachLine(
                                            "Location: ",
                                            intLine,
                                            event
                                                    .getString(
                                                            BlackBerryEvent.LOCATION,
                                                            j));
                                }
                            }
                            if (eventList
                                    .isSupportedField(BlackBerryEvent.START)) {
                                int intEventStart = event
                                        .countValues(BlackBerryEvent.START);
                                long[] longStartTime = new long[intEventStart];
                                long[] longStartDayMidnight = new long[intEventStart];
                                long[] longDs = new long[intEventStart];
                                long[] longTheDayStartTime = new long[intEventStart];
                                for (int j = 0; j < intEventStart; ++j) {
                                    longStartTime[j] = event.getDate(
                                            BlackBerryEvent.START, j);
                                    longStartDayMidnight[j] = event.getDate(
                                            BlackBerryEvent.START, j)
                                            - (event.getDate(
                                                    BlackBerryEvent.START, j) + TimeZone
                                                    .getDefault()
                                                    .getRawOffset())
                                            % longOneday;
                                    longDs[j] = longStartTime[j]
                                            - longStartDayMidnight[j];
                                    longTheDayStartTime[j] = longTheDayMidnight
                                            + longDs[j];
                                    intLine = printEachLine(
                                            "   Start: ",
                                            intLine,
                                            dateFormatDateFull
                                                    .formatLocal(longTheDayStartTime[j])
                                                    + " "
                                                    + dateFormatTimeDefault
                                                            .formatLocal(longTheDayStartTime[j]));
                                }
                                int intEventEnd = 0;
                                if (eventList
                                        .isSupportedField(BlackBerryEvent.END)) {
                                    intEventEnd = event
                                            .countValues(BlackBerryEvent.END);
                                }
                                long[] longEndTime = new long[intEventEnd];
                                long[] longEndTimeMinusStartTime = new long[intEventEnd];
                                long[] longTheDayEndTime = new long[intEventEnd];
                                for (int j = 0; j < intEventEnd; ++j) {
                                    longEndTime[j] = event.getDate(
                                            BlackBerryEvent.END, j);
                                    longEndTimeMinusStartTime[j] = longEndTime[j]
                                            - longStartTime[j];
                                    longTheDayEndTime[j] = longTheDayStartTime[j]
                                            + longEndTimeMinusStartTime[j];
                                    intLine = printEachLine(
                                            "     End: ",
                                            intLine,
                                            dateFormatDateFull
                                                    .formatLocal(longTheDayEndTime[j])
                                                    + " "
                                                    + dateFormatTimeDefault
                                                            .formatLocal(longTheDayEndTime[j]));
                                }
                            }
                            if (eventList
                                    .isSupportedField(BlackBerryEvent.NOTE)) {
                                for (int j = 0; j < event
                                        .countValues(BlackBerryEvent.NOTE); ++j) {
                                    intLine = printEachLine("   Notes: ",
                                            intLine, event.getString(
                                                    BlackBerryEvent.NOTE, j));
                                }
                            }
                            if (enumTheDayTimeEvents.hasMoreElements()) {
                                intLine = lineOrPageFeed(intLine);
                            }
                        }
                    }
                }
                basicPrinting.mpEscpPrint();
            }
            basicPrinting.mpEscpUninit();
        }

        /**
         * @param stringIndexString
         * @param line
         * @param stringAllStrings
         * @return
         */
        private int printEachLine(String stringIndexString, int line,
                String stringAllStrings) {
            if (stringAllStrings != null && stringAllStrings != "") {
                String strLeft = stringAllStrings;
                strLeft = strLeft.replace('\t', ' ');
                strLeft = strLeft.replace('\n', '\r');
                strLeft = strLeft.replace('\f', '\r');
                strLeft = strLeft.replace('\r', '\r');
                strLeft = trimString(strLeft);
                booleanFirstLine = true;
                int intNumberOfSpacer = stringIndexString.length();
                String stringSpacer = new String();
                for (int i = 0; i < intNumberOfSpacer; i++) {
                    stringSpacer = stringSpacer + (" ");
                }
                if (strLeft.length() <= (49 + 1 - intNumberOfSpacer)
                        && strLeft.lastIndexOf('\r') == -1) {
                    basicPrinting.mpEscpFormatCtrl(0, 11, 0);
                    if (booleanFirstLine) {
                        basicPrinting.mpEscpOutChar(stringIndexString);
                        booleanFirstLine = false;
                    } else {
                        basicPrinting.mpEscpOutChar(stringSpacer);
                    }
                    basicPrinting.mpEscpFormatCtrl(0, 3, 0);
                    basicPrinting.mpEscpOutChar(strLeft);
                    line = lineOrPageFeed(line);
                } else {
                    basicPrinting.mpEscpFormatCtrl(0, 11, 0);
                    if (booleanFirstLine) {
                        basicPrinting.mpEscpOutChar(stringIndexString);
                        booleanFirstLine = false;
                    } else {
                        basicPrinting.mpEscpOutChar(stringSpacer);
                    }
                    line = lineOrPageFeed(line);
                    basicPrinting.mpEscpFormatCtrl(0, 3, 0);
                    String strWork = new String();
                    int intLastIndex;
                    int intIndexOfLF;
                    while (strLeft.length() > 49) {
                        strWork = strLeft.substring(0, 49);
                        intLastIndex = 48;
                        intIndexOfLF = strWork.indexOf('\r');
                        if (intIndexOfLF == -1) {
                            int intLastIndexOfSpace = strWork.lastIndexOf(32);
                            if (intLastIndexOfSpace == -1) {
                                basicPrinting.mpEscpOutChar(strLeft.substring(
                                        0, intLastIndex + 1));
                                line = lineOrPageFeed(line);
                                strWork = trimString(strLeft
                                        .substring(intLastIndex + 1));
                            } else {
                                intLastIndex = intLastIndexOfSpace;
                                basicPrinting.mpEscpOutChar(strLeft.substring(
                                        0, intLastIndex));
                                line = lineOrPageFeed(line);
                                strWork = trimString(strLeft
                                        .substring(intLastIndex + 1));
                            }
                        } else if (intIndexOfLF != -1) {
                            intLastIndex = intIndexOfLF;
                            basicPrinting.mpEscpOutChar(strLeft.substring(0,
                                    intLastIndex));
                            line = lineOrPageFeed(line);
                            strWork = trimString(strLeft
                                    .substring(intLastIndex + 1));
                        }
                        strLeft = strWork;
                    }
                    intIndexOfLF = strLeft.indexOf('\r');
                    while (intIndexOfLF != -1) {
                        intLastIndex = intIndexOfLF;
                        basicPrinting.mpEscpOutChar(strLeft.substring(0,
                                intLastIndex));
                        line = lineOrPageFeed(line);
                        strWork = trimString(strLeft
                                .substring(intLastIndex + 1));
                        strLeft = strWork;
                        intIndexOfLF = strLeft.indexOf('\r');
                    }
                    basicPrinting.mpEscpOutChar(trimString(strLeft));
                    line = lineOrPageFeed(line);
                    strLeft = null;
                }
            }
            return line;
        }

        /**
         * @param stringTrimString
         * @return
         */
        private String trimString(String stringTrimString) {
            stringTrimString.trim();
            if (stringTrimString.length() > 2) {
                while (stringTrimString.length() > 2
                        && (stringTrimString.charAt(0) == '\r' || stringTrimString
                                .charAt(0) == ' ')
                        && (stringTrimString.charAt(1) == '\r' || stringTrimString
                                .charAt(1) == ' ')) {
                    if (stringTrimString.charAt(0) == '\r') {
                        if (stringTrimString.charAt(1) == '\r') {
                            stringTrimString = stringTrimString.substring(1);
                        } else if (stringTrimString.charAt(1) == ' ') {
                            stringTrimString = stringTrimString.substring(1);
                        }
                    }
                    if (stringTrimString.charAt(0) == ' ') {
                        if (stringTrimString.charAt(1) == '\r') {
                            stringTrimString = stringTrimString.substring(1);
                        } else if (stringTrimString.charAt(1) == ' ') {
                            stringTrimString = stringTrimString.substring(1);
                        }
                    }
                }
            }
            if (stringTrimString.length() > 1) {
                if (stringTrimString.charAt(0) == '\r') {
                    stringTrimString = stringTrimString.substring(1);
                }
                if (stringTrimString.charAt(0) == ' ') {
                    stringTrimString = stringTrimString.substring(1);
                }
            }
            return stringTrimString;
        }

        /**
         * @param line
         * @return line
         */
        private int lineOrPageFeed(int line) {
            line++;
            if (line == 24) {
                basicPrinting.mpEscpPrint();
                line = 0;
            } else {
                verticalMovement.escpLineFeed();
            }
            return line;
        }
    }
}

package com.brother.mprint.bb.escp.apps;

import net.rim.blackberry.api.mail.Message;
import net.rim.blackberry.api.mail.MessagingException;
import net.rim.blackberry.api.menuitem.ApplicationMenuItem;
import net.rim.blackberry.api.menuitem.ApplicationMenuItemRepository;
import net.rim.device.api.i18n.DateFormat;
import net.rim.device.api.i18n.SimpleDateFormat;
import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.Dialog;

import com.brother.mprint.bb.escp.CommunicationPort;
import com.brother.mprint.bb.escp.Connection;
import com.brother.mprint.bb.escp.commands.VerticalMovement;
import com.brother.mprint.bb.escp.sdk.BasicPrinting;

/**
 * @author oyoshida
 */
class BBMessagesPrint extends UiApplication {
    /**
     * @param args
     */
    public static void main(String[] args) {
        BBMessagesPrint theApp = new BBMessagesPrint();
        theApp.enterEventDispatcher();
    }

    private BBMessagesPrint() {
        addMenu();
    }

    private void addMenu() {
        PrintMenuInMessages myMenuitem = new PrintMenuInMessages(0);
        ApplicationMenuItemRepository.getInstance().addMenuItem(
                ApplicationMenuItemRepository.MENUITEM_EMAIL_VIEW, myMenuitem);
        ApplicationMenuItemRepository.getInstance().addMenuItem(
                ApplicationMenuItemRepository.MENUITEM_EMAIL_EDIT, myMenuitem);
        System.exit(0);
    }
}

/**
 * @author oyoshida
 */

class PrintMenuInMessages extends ApplicationMenuItem {
    VerticalMovement verticalMovement = new VerticalMovement();

    BasicPrinting basicPrinting = BasicPrinting.getInstance();

    Message message;

    /**
     * @param order
     */
    PrintMenuInMessages(int order) {
        super(order);
    }

    public Object run(Object context) {
        if (context instanceof Message) {
            message = (Message) context;
            PrintThread printThread = new PrintThread();
            printThread.start();
        } else {
            Dialog.alert("This is not e-mail message.");
        }
        return context;
    }

    public String toString() {
        return "Print...";
    }

    /**
     * @author oyoshida
     */
    private class PrintThread extends Thread {
        SimpleDateFormat dateFormatDateFull;

        SimpleDateFormat dateFormatTimeDefault;

        int intLine;

        boolean booleanFirstLine;

        PrintThread() {
            dateFormatDateFull = new SimpleDateFormat(DateFormat.DATE_FULL);
            dateFormatTimeDefault = new SimpleDateFormat(
                    DateFormat.TIME_DEFAULT);
            intLine = 0;
        }

        public void run() {
            if (true)
                if (basicPrinting.mpEscpInit(CommunicationPort.COMMUNICATION_PORT_BLUETOOTH, Connection.orientationSetting)) {
                    basicPrinting.mpEscpPositionCtrl(0, 0);
                    intLine = printEachLine(" Subject: ", intLine, message
                            .getSubject());
                    if (message.getStatus() == Message.Status.TX_SENT
                            | message.getStatus() == Message.Status.RX_RECEIVED) {
                        intLine = printEachLine("    Sent: ", intLine,
                                dateFormatDateFull.formatLocal(message
                                        .getSentDate().getTime())
                                        + " "
                                        + dateFormatTimeDefault
                                                .formatLocal(message
                                                        .getSentDate()
                                                        .getTime()));
                    }
                    try {
                        String stringAllTo = new String();
                        for (int i = 0; i < message
                                .getRecipients(Message.RecipientType.TO).length; i++) {
                            if (message.getRecipients(Message.RecipientType.TO)[i] != null) {
                                if (message
                                        .getRecipients(Message.RecipientType.TO)[i]
                                        .getName() != null
                                        && message
                                                .getRecipients(Message.RecipientType.TO)[i]
                                                .getName() != "") {
                                    if (i == 0) {
                                        stringAllTo = stringAllTo
                                                + message
                                                        .getRecipients(Message.RecipientType.TO)[i]
                                                        .getName();
                                    } else {
                                        stringAllTo = stringAllTo
                                                + "; " + message
                                                        .getRecipients(Message.RecipientType.TO)[i]
                                                        .getName();
                                    }                                        
                                } else {
                                    if (i == 0) {
                                        stringAllTo = stringAllTo
                                                + message
                                                        .getRecipients(Message.RecipientType.TO)[i]
                                                        .getName();
                                    } else {
                                        stringAllTo = stringAllTo
                                        + "; " + message
                                                .getRecipients(Message.RecipientType.TO)[i]
                                                .getName();
                                    }                                        
                                }
                            }
                        }
                        intLine = printEachLine("      To: ", intLine,
                                stringAllTo);
                    } catch (MessagingException me) {
                    }
                    try {
                        String stringAllFrom = new String();
                        if (message.getFrom() != null) {
                            if (message.getFrom().getName() != null
                                    && message.getFrom().getName() != "") {
                                stringAllFrom = stringAllFrom
                                        + message.getFrom().getName();
                            } else {
                                stringAllFrom = stringAllFrom
                                        + message.getFrom().getAddr();
                            }
                        }
                        intLine = printEachLine("    From: ", intLine,
                                stringAllFrom);
                    } catch (Exception e) {
                    }
                    intLine = printEachLine("", intLine, message.getBodyText());
                    basicPrinting.mpEscpPrint();
                }
            basicPrinting.mpEscpUninit();
        }

        /**
         * @param stringIndexString
         * @param line
         * @param stringAllStrings
         * @return
         */
        private int printEachLine(String stringIndexString, int line,
                String stringAllStrings) {
            if (stringAllStrings != null && stringAllStrings != "") {
                String strLeft = stringAllStrings;
                strLeft = strLeft.replace('\t', ' ');
                strLeft = strLeft.replace('\n', '\r');
                strLeft = strLeft.replace('\f', '\r');
                strLeft = strLeft.replace('\r', '\r');
                strLeft = trimString(strLeft);
                booleanFirstLine = true;
                int intNumberOfSpacer = stringIndexString.length();
                String stringSpacer = new String();
                for (int i = 0; i < intNumberOfSpacer; i++) {
                    stringSpacer = stringSpacer + (" ");
                }
                if (strLeft.length() <= (49 + 1 - intNumberOfSpacer)
                        && strLeft.lastIndexOf('\r') == -1) {
                    basicPrinting.mpEscpFormatCtrl(0, 11, 0);
                    if (booleanFirstLine) {
                        basicPrinting.mpEscpOutChar(stringIndexString);
                        booleanFirstLine = false;
                    } else {
                        basicPrinting.mpEscpOutChar(stringSpacer);
                    }
                    basicPrinting.mpEscpFormatCtrl(0, 3, 0);
                    basicPrinting.mpEscpOutChar(strLeft);
                    line = lineOrPageFeed(line);
                } else {
                    basicPrinting.mpEscpFormatCtrl(0, 11, 0);
                    if (booleanFirstLine) {
                        basicPrinting.mpEscpOutChar(stringIndexString);
                        booleanFirstLine = false;
                    } else {
                        basicPrinting.mpEscpOutChar(stringSpacer);
                    }
                    line = lineOrPageFeed(line);
                    basicPrinting.mpEscpFormatCtrl(0, 3, 0);
                    String strWork = new String();
                    int intLastIndex;
                    int intIndexOfLF;
                    while (strLeft.length() > 49) {
                        strWork = strLeft.substring(0, 49);
                        intLastIndex = 48;
                        intIndexOfLF = strWork.indexOf('\r');
                        if (intIndexOfLF == -1) {
                            int intLastIndexOfSpace = strWork.lastIndexOf(32);
                            if (intLastIndexOfSpace == -1) {
                                basicPrinting.mpEscpOutChar(strLeft.substring(
                                        0, intLastIndex + 1));
                                line = lineOrPageFeed(line);
                                strWork = trimString(strLeft
                                        .substring(intLastIndex + 1));
                            } else {
                                intLastIndex = intLastIndexOfSpace;
                                basicPrinting.mpEscpOutChar(strLeft.substring(
                                        0, intLastIndex));
                                line = lineOrPageFeed(line);
                                strWork = trimString(strLeft
                                        .substring(intLastIndex + 1));
                            }
                        } else if (intIndexOfLF != -1) {
                            intLastIndex = intIndexOfLF;
                            basicPrinting.mpEscpOutChar(strLeft.substring(0,
                                    intLastIndex));
                            line = lineOrPageFeed(line);
                            strWork = trimString(strLeft
                                    .substring(intLastIndex + 1));
                        }
                        strLeft = strWork;
                    }
                    intIndexOfLF = strLeft.indexOf('\r');
                    while (intIndexOfLF != -1) {
                        intLastIndex = intIndexOfLF;
                        basicPrinting.mpEscpOutChar(strLeft.substring(0,
                                intLastIndex));
                        line = lineOrPageFeed(line);
                        strWork = trimString(strLeft
                                .substring(intLastIndex + 1));
                        strLeft = strWork;
                        intIndexOfLF = strLeft.indexOf('\r');
                    }
                    basicPrinting.mpEscpOutChar(trimString(strLeft));
                    line = lineOrPageFeed(line);
                    strLeft = null;
                }
            }
            return line;
        }

        /**
         * @param stringTrimString
         * @return
         */
        private String trimString(String stringTrimString) {
            stringTrimString.trim();
            if (stringTrimString.length() > 2) {
                while (stringTrimString.length() > 2
                        && (stringTrimString.charAt(0) == '\r' || stringTrimString
                                .charAt(0) == ' ')
                        && (stringTrimString.charAt(1) == '\r' || stringTrimString
                                .charAt(1) == ' ')) {
                    if (stringTrimString.charAt(0) == '\r') {
                        if (stringTrimString.charAt(1) == '\r') {
                            stringTrimString = stringTrimString.substring(1);
                        } else if (stringTrimString.charAt(1) == ' ') {
                            stringTrimString = stringTrimString.substring(1);
                        }
                    }
                    if (stringTrimString.charAt(0) == ' ') {
                        if (stringTrimString.charAt(1) == '\r') {
                            stringTrimString = stringTrimString.substring(1);
                        } else if (stringTrimString.charAt(1) == ' ') {
                            stringTrimString = stringTrimString.substring(1);
                        }
                    }
                }
            }
            if (stringTrimString.length() > 1) {
                if (stringTrimString.charAt(0) == '\r') {
                    stringTrimString = stringTrimString.substring(1);
                }
                if (stringTrimString.charAt(0) == ' ') {
                    stringTrimString = stringTrimString.substring(1);
                }
            }
            return stringTrimString;
        }

        /**
         * @param line
         * @return line
         */
        private int lineOrPageFeed(int line) {
            line++;
            if (line == 24) {
                basicPrinting.mpEscpPrint();
                line = 0;
            } else {
                verticalMovement.escpLineFeed();
            }
            return line;
        }
    }
}

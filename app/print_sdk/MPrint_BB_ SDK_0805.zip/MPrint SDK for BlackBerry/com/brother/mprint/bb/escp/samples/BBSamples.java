package com.brother.mprint.bb.escp.samples;

import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.LabelField;
import net.rim.device.api.ui.container.MainScreen;
import net.rim.device.api.ui.component.ButtonField;
import net.rim.device.api.system.Characters;

public class BBSamples extends UiApplication {
    public static void main(String[] args) {
        BBSamples theApp = new BBSamples();
        theApp.enterEventDispatcher();
    }

     public BBSamples() {
        MenuScreen menuScreen = new MenuScreen();
        pushScreen(menuScreen);
    }
}

final class MenuScreen extends MainScreen {
    ButtonField bBBarCodeButton;
    ButtonField bBHelloWorldButton;
    ButtonField bBHealthCareButton;
    public MenuScreen() {
        super();
        LabelField title = new LabelField("BBSamples", LabelField.ELLIPSIS | LabelField.USE_ALL_WIDTH);
        setTitle(title);
        bBBarCodeButton = new ButtonField("BBBarCode");
        add(bBBarCodeButton);
        bBHelloWorldButton = new ButtonField("BBHelloWorld");
        add(bBHelloWorldButton);
        bBHealthCareButton = new ButtonField("BBHealthCare");
        add(bBHealthCareButton);
    }

    public boolean trackwheelClick(int status, int time)
    {
        if(!super.trackwheelClick(status, time)) {
            Field field = this.getLeafFieldWithFocus();
            if (field.equals(bBBarCodeButton)) {
                BBBarCodeScreen bBBarCodeScreen = new BBBarCodeScreen();
                UiApplication.getUiApplication().pushScreen(bBBarCodeScreen);
                return true;
            }
            if (field.equals(bBHelloWorldButton)) {
                BBHelloWorldScreen bBHelloWorldScreen = new BBHelloWorldScreen();
                UiApplication.getUiApplication().pushScreen(bBHelloWorldScreen);
                return true;
            }
            if (field.equals(bBHealthCareButton)) {
                BBHealthCareScreen bBHealthCareScreen = new BBHealthCareScreen();
                UiApplication.getUiApplication().pushScreen(bBHealthCareScreen);
                return true;
            }
        }
        return false;
    }

    public boolean keyChar(char key, int status, int time) {
        boolean retval = false;
        switch (key) {
            case Characters.ESCAPE:
                System.exit(0);
                retval = true;
                break;
            }
        return retval;
    }
}

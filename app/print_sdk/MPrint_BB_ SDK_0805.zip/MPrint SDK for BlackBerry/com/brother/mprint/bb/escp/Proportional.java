package com.brother.mprint.bb.escp;

/**
 * Defines the fields for the proportional. <br>
 * @author oyoshida
 */
public interface Proportional {

	/**
	 * Predefined Cancelled used for the proportional characters. <br>
	 */
	public static final int PROPORTIONAL_CANCELLED = 0;

	/**
	 * Predefined Applied used for the proportional characters. <br>
	 */
	public static final int PROPORTIONAL_APPLIED = 1;

}
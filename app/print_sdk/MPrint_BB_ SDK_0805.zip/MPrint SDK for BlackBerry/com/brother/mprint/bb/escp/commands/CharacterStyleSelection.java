package com.brother.mprint.bb.escp.commands;

import com.brother.mprint.bb.escp.EscpCommand;

/**
 * Provides ESC/P command for character style. <br>
 * @author naoki
 */
public class CharacterStyleSelection extends EscpCommand {
    /**
     * Stores the Select International Character Set command with parameter in
     * the transmitting buffer. <br><br>
     * The Select International Character Set command is as follows: <br><br>
     * ESC R Select international character set. <br>
     * [ASCII] ESC R n <br>
     * [Decimal] 27 82 n <br>
     * [Hexadecimal] 1B 52 n <br>
     * [Parameters] 0 <= n <= 13, 64 <br>
     * [Description] <br>- Selects the character code section of the code table
     * according to the value of n.<br>
     * n=0: United States <br>
     * n=1: France <br>
     * n=2: Germany <br>
     * n=3: Britain <br>
     * n=4: Denmark <br>
     * n=5: Sweden <br>
     * n=6: Italy <br>
     * n=7: Spain <br>
     * n=8: Japan <br>
     * n=9: Norway <br>
     * n=10: Denmark II <br>
     * n=11: Spain II <br>
     * n=12: Latin America <br>
     * n=13: Korea <br>
     * n=64: Legal <br>- The following 12 switch codes can be used. <br>
     * 23h, 24h, 40h, 5Bh, 5Ch, 5Dh, <br>
     * 5Eh, 60h, 7Bh, 7Ch, 7Dh, 7Eh <br>- The default setting is n=0 (United
     * States). <br><br>
     * [Example] <br>
     * Code <br>
     * 
     * <pre>
     *       5Ch ESC R 08h 5Ch FF
     * </pre>
     * 
     * Print result <br>
     * 
     * <pre>
     *       \ &#165;
     * </pre>
     * 
     * @param internationalCharacterSet Specifies the internatinal character set. Please choose from INTERNATIONAL_CHARACTER_SET_ fields. 
     */
    public void escpInternationalCharacterSet(int internationalCharacterSet) {
        if ((0 <= internationalCharacterSet && internationalCharacterSet <= 13) || internationalCharacterSet == 64) {
            byte[] buffer = { 0x1b, 0x52, (byte) internationalCharacterSet };
            mpEscpCommand(buffer);
        }
    }

    /**
     * Stores the Select Character Style command with parameter in the
     * transmitting buffer. <br><br>
     * The Select Character Style command is as follows: <br><br>
     * ESC q Select character style. <br>
     * [ASCII] ESC q n <br>
     * [Decimal] 27 113 n <br>
     * [Hexadecimal] 1B 71 n <br>
     * [Parameters] 0 <= n <= 3 <br>
     * [Description] <br>- Selects the character style. <br>
     * n=0: Cancel (normal characters) <br>
     * n=1: Outline <br>
     * n=2: Shadow <br>
     * n=3: Shadow and outline <br><br>
     * [Example] <br>
     * Code <br>
     * 
     * <pre>
     *       ABC ESC q 02h ABC ESC q 00h ABC FF
     * </pre>
     * 
     * Print result <br>
     * 
     * <pre>
     *       ABC<b>ABC</b>ABC
     * </pre>
     * 
     * @param characterStyle Specifies the character style. Please choose from CHARACTER_STYLE_ fields. 
     */
    public void escpCharacterStyle(int characterStyle) {
        if (0 <= characterStyle && characterStyle <= 3) {
            byte[] buffer = { 0x1b, 0x71, (byte) characterStyle };
            mpEscpCommand(buffer);
        }
    }

    /**
     * Stores the Select Font command with parameter in the transmitting buffer.
     * <br><br>
     * The Select Font command is as follows: <br><br>
     * ESC k Select font. <br>
     * [ASCII] ESC k n <br>
     * [Decimal] 27 107 n <br>
     * [Hexadecimal] 1B 6B n <br>
     * [Parameters] 0 <= n <= 4 <br>
     * [Description] <br>- Selects the font. <br>
     * n=0 Brougham (better with a fixed pitch) <br>
     * n=1 Letter Gothic Bold (better with a fixed pitch) <br>
     * n=2 Brussels (better with a proportional pitch) <br>
     * n=3 Helsinki (better with a proportional pitch) <br>
     * n=4 San Diego (better with a proportional pitch) <br>- The default
     * setting is n=0 Brougham (better with a fixed pitch). <br>
     * 
     * @param font Specifies the font. Please choose from FONT_ fields. 
     */
    public void escpFont(int font) {
        if (0 <= font && font <= 4) {
            byte[] buffer = { 0x1b, 0x6b, (byte) font };
            mpEscpCommand(buffer);
        }
    }

    /**
     * Stores the Select Character Code Table command with parameter in the
     * transmitting buffer. <br><br>
     * The Select Character Code Table command is as follows: <br><br>
     * ESC t Select character code table. <br>
     * [ASCII] ESC t n <br>
     * [Decimal] 27 116 n <br>
     * [Hexadecimal] 1B 74 n <br>
     * [Parameters] n=0, 1, 2 <br>
     * [Description] <br>
     * - From the two built-in character code tables, selects the character code table to be used. <br>
     * - n=0: Code table for regular characters <br>
     * - n=1: Code table for Eastern European characters <br>
     * - n=2: Code table for Western European characters <br>
     * - n=3: (Spare) <br>
     * - The default setting is n=0. <br>
     * 
     * @param characterCodeTable Specifies the character code table. Please choose from CHARACTER_CODE_TABLE_ fields. 
     */
    public void escpCharacterCodeTable(int characterCodeTable) {
        if (0 <= characterCodeTable && characterCodeTable <= 2) {
            byte[] buffer = { 0x1b, 0x74, (byte) characterCodeTable };
            mpEscpCommand(buffer);
        }
    }
}
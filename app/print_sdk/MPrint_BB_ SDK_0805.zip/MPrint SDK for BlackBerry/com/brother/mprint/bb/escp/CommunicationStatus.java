package com.brother.mprint.bb.escp;

/**
 * Defines the fields for the communication status. <br>
 * @author oyoshida
 */
public interface CommunicationStatus {

	/**
	 * Indicates the communication status when the communication is established
	 * and the error occurs. <br>
	 */
	public static final int COMMUNICATION_STATUS_COMMUNICATED_ERROR = -2;

	/**
	 * Indicates the communication status when the error occurs and the
	 * communication is locked. <br>
	 */
	public static final int COMMUNICATION_STATUS_COMMUNICATED_LOCKED = -1;

	/**
	 * Indicates the communication status when there is no communication. <br>
	 */
	public static final int COMMUNICATION_STATUS_NO_COMMUNICATION = 0;

	/**
	 * Indicates the communication status when the communication is established.
	 * <br>
	 */
	public static final int COMMUNICATION_STATUS_COMMUNICATED = 1;

}
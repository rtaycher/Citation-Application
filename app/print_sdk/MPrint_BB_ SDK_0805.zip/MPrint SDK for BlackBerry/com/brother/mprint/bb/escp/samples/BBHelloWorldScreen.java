package com.brother.mprint.bb.escp.samples;

import com.brother.mprint.bb.escp.sdk.BasicPrinting;
import com.brother.mprint.bb.escp.CommunicationPort;
import com.brother.mprint.bb.escp.Connection;

import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.component.LabelField;
import net.rim.device.api.ui.container.MainScreen;
import net.rim.device.api.ui.component.ButtonField;
import net.rim.device.api.system.Characters;

class BBHelloWorldScreen extends MainScreen {
    LabelField labelField;
    ButtonField printButton;
    public BBHelloWorldScreen() {
        labelField = new LabelField("*** Print \"Hello World\" ***");
        add(labelField);
        printButton = new ButtonField("Print...");
        add(printButton);
    }

    public boolean trackwheelClick(int status, int time)
    {
        if(!super.trackwheelClick(status, time)) {
            Field field = this.getLeafFieldWithFocus();
            if (field.equals(printButton)) {
                PrintThread printThread = new PrintThread();
                printThread.start();
                return true;
            }
        }
        return false;
    }

    public boolean keyChar(char key, int status, int time) {
        boolean retval = false;
        switch (key) {
            case Characters.ESCAPE:
                close();
                retval = true;
                break;
            }
        return retval;
    }

    static class PrintThread extends Thread implements CommunicationPort {
        BasicPrinting basicPrinting;
        public void run() {
            basicPrinting = BasicPrinting.getInstance();

            basicPrinting.mpEscpInit(CommunicationPort.COMMUNICATION_PORT_BLUETOOTH,Connection.orientationSetting);
            basicPrinting.mpEscpPositionCtrl(0, 0);
            basicPrinting.mpEscpFormatCtrl(0, 3, 0);
            basicPrinting.mpEscpOutChar("Hello World!");
            basicPrinting.mpEscpPrint();
            basicPrinting.mpEscpUninit();
        }
    }
}

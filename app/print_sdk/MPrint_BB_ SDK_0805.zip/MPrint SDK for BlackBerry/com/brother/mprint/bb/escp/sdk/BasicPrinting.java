package com.brother.mprint.bb.escp.sdk;

import com.brother.mprint.bb.escp.BluetoothConnection;
import com.brother.mprint.bb.escp.CommunicationPort;
import com.brother.mprint.bb.escp.CommunicationStatus;
import com.brother.mprint.bb.escp.Connection;
import com.brother.mprint.bb.escp.Orientation;
import com.brother.mprint.bb.escp.commands.CharacterStyleSelection;
import com.brother.mprint.bb.escp.commands.HorizontalMovement;
import com.brother.mprint.bb.escp.commands.TextPrinting;
import com.brother.mprint.bb.escp.commands.VerticalMovement;
import com.brother.mprint.bb.escp.EscpCommand;

/**
 * Provides a basic function group for Bluetooth ESC/P printing from the BlackBerry to MPrint. <br>
 * <h1>Overview</h1>
 * This class is the basic class in Brother MPrint SDK for BlackBerry. <br>
 * It provides a basic function group for Bluetooth ESC/P printing from the
 * BlackBerry to MPrint. <br>
 * You can easily integrate printing into your applications with com.brother.mprint.bb.escp.sdk.BasicPrinting class, 
 * com.brother.mprint.bb.escp.BlutoothConnection (in BlutoothConnectionLibrary.jar) 
 * and RIM SDK. (RIM developer registration is required to obtain digital signature. 
 * For detailed information please see www.blackberry.com.) <br>
 * @author oyoshida
 */
public class BasicPrinting extends EscpCommand implements Orientation, CommunicationPort {
    BluetoothConnection bluetoothConnection = BluetoothConnection.getInstance();

    CharacterStyleSelection characterStyleSelection = new CharacterStyleSelection();

    TextPrinting textPrinting = new TextPrinting();

    VerticalMovement verticalMovement = new VerticalMovement();

    HorizontalMovement horizontalMovement = new HorizontalMovement();

    /**
     * Stores the communication port. <br>
     */
    public static int COMMUNICATION_PORT;

    /**
     * Represents the charactor bit mode (ANK mode / Chinese charactor mode).
     * <br>
     * MW-140BT Western Language Model use only ANK mode. <br>
     */
    private static int CHARACTER_BIT_MODE = 0;

    /**
     * Represents the unique instance of this class. <br>
     */
    private static final BasicPrinting basicPrinting = new BasicPrinting();

    /**
     * Private constructor. <br>
     */
    private BasicPrinting() {
        //Do nothing
    }

    /**
     * Gets the unique instance of this class. <br>
     * 
     * @return the unique instance of this class. <br>
     */
    public static BasicPrinting getInstance() {
        return basicPrinting;
    }

    /**
     * Performs a series of initialization processes. <br><br>
     * Specifically, checking OS version, initializing transmitting buffer,
     * building Bluetooth connection, changing command mode to ESC/P mode,
     * initializing printer control, waiting the end and so on. <br>
     * @param port
     *            Specified the communication port.
     * @param orientation
     *            Specified the orientation.
     * @return true if it succeed; false otherwise.
     */
    public boolean mpEscpInit(int port, int orientation) {
        COMMUNICATION_PORT = port;
        Connection.orientationSetting = orientation;
        if (COMMUNICATION_PORT == COMMUNICATION_PORT_BLUETOOTH) {
            Connection.communicationStatus = CommunicationStatus.COMMUNICATION_STATUS_NO_COMMUNICATION;
            bluetoothConnection.initializeAndWait();
            if (Connection.communicationStatus != CommunicationStatus.COMMUNICATION_STATUS_COMMUNICATED) {
                return false;
            }
        } else {
            bluetoothConnection.invokeAndWaitAlert("Only the Bluetooth is available so far. ");
            System.exit(1);
            return false;
        }
        return true;
    }

    /**
     * Set the charactor mode and styles. <br><br>
     * The specification of iMode is as follows. <br>
     * <ul>
     * <li>0: ANK mode
     * <li>1: Chinese charactor mode
     * </ul>
     * MW-140BT Western Language Model use only ANK mode. The specification of
     * iCharForm is as follows. <br>
     * When ANK mode is selected <br>
     * <ul>
     * <li>Specifies a combination of the various print modes.
     * <li>Specifies the mode according to each bit of the value of n.
     * <li>The setting of emphasis here is also effective in the Chinese
     * character mode.
     * <li>The setting of double width here is also effective in the Chinese
     * character mode.
     * <li>Priority is given in order from bit 5 to bit 2.
     * <li>Bit 0 is available only if bit 1 is "0".
     * </ul><br>
     * <table border=1>
     * <tr>
     * <th>bit</th>
     * <th>7</th>
     * <th>6</th>
     * <th>5</th>
     * <th>4</th>
     * <th>3</th>
     * <th>2</th>
     * <th>1</th>
     * <th>0</th>
     * </tr>
     * <tr>
     * <td>If 1</td>
     * <td>Under line</td>
     * <td>Italics</td>
     * <td>Double width</td>
     * <td>Double height</td>
     * <td>Emphasis</td>
     * <td>Reduced</td>
     * <td>Proportional</td>
     * <td>12 cpi</td>
     * <tr>
     * <tr>
     * <td>If 0</td>
     * <td>Cancel</td>
     * <td>Cancel</td>
     * <td>Cancel</td>
     * <td>Cancel</td>
     * <td>Cancel</td>
     * <td>Cancel</td>
     * <td>Cancel</td>
     * <td>10 cpi</td>
     * </tr>
     * </table><br>
     * The specification of iCharForm is as follows. <br>
     * If you don't want to set emphasis, please set 0.<br>
     * <ul>
     * <li>0: Bold
     * <li>1: Outline
     * <li>2: Shadow
     * <li>3: Shadow and Outline
     * </ul>
     * 
     * @param mode
     *            Represents the charactor bit mode (ANK mode / Chinese
     *            charactor mode). MW-140BT Western Language Model use only ANK
     *            mode.
     * @param charForm
     *            Specifies a combination of the various print modes.
     * @param style
     *            Specifies the emphasis style when emphasis is set with
     *            iCharForm.
     * @return true if it succeed; false otherwise.
     */
    public boolean mpEscpFormatCtrl(int mode, int charForm, int style) {
        if (Connection.communicationStatus == CommunicationStatus.COMMUNICATION_STATUS_COMMUNICATED) {
            if (mode == 0) {
                textPrinting.escpGrobalFormatting(charForm);
                if (1 <= style && style <= 3) {
                    characterStyleSelection.escpCharacterStyle(style);
                }
                CHARACTER_BIT_MODE = mode;
            }
            return true;
        } else {
            return false;
        }
    }

    /**
     * Specifies the line feed amount, horizontal position and the vertical
     * position. <br><br>
     * The specification of iCharPosX is as follows. <br>
     * <ul>
     * <li>0: specifies a left alignment.
     * <li>1: specifies a center alignment.
     * <li>2: specifies a right alignment.
     * <li>>3: Specifies an absolute position in dots for the print position from left.
     * </ul>
     * The specification of iCharPosY is as follows. <br>
     * <ul>
     * <li>0: No line feed.
     * <li>>1: Specifies an absolute position in dots for the print position
     * from top.
     * </ul>
     * Even if it specifies 0 by iCharPosY, if mpESCP_PositionCtrl is called
     * except the head of a line, a new line for one line will be started automatically. <br>
     * 
     * @param xPosition
     *            Specifies the horizontal position
     * @param yPosition
     *            Specifies the vertical position
     * @return true if it succeed; false otherwise.
     */
    public boolean mpEscpPositionCtrl(int xPosition, int yPosition) {
        if (Connection.communicationStatus == CommunicationStatus.COMMUNICATION_STATUS_COMMUNICATED) {
        	if (getnL(xPosition) != -1 && getnH(xPosition) != -1 && getnL(yPosition) != -1 && getnH(yPosition) != -1) {
	            if (0 <= xPosition && xPosition <= 2) {
	                horizontalMovement.escpSpecifyAlignment(xPosition);
	            } else {
	                horizontalMovement.escpSpecifyAbsoluteHorizontalPosition(xPosition);
	            }
	            if (yPosition != 0) {
	                verticalMovement.escpSpecifyAbsoluteVerticalPosition(yPosition);
	            }
	            return true;
        	} else {
        		return false;
        	}
        } else {
            return false;
        }
    }

    /**
	 * Store the character string in a text buffer. <br><br>
	 * One byte characters and 2 byte characters cannot be made intermingled by
	 * one call. <br>
	 * MW-140BT Western Language Model use only ANK mode.<br>
	 * 
	 * @param str
	 *            Specifies the character string stored in a text buffer.
	 * @return true if it succeed; false otherwise.
	 */
    public boolean mpEscpOutChar(String str) {
        if (Connection.communicationStatus == CommunicationStatus.COMMUNICATION_STATUS_COMMUNICATED) {
            int strLength;
            strLength = str.length();
            byte[] strByte = new byte[strLength];
            strByte = str.getBytes();
            Byte byteObj;
            if (CHARACTER_BIT_MODE == 0) {
                for (int i = 0; i < strLength; i++) {
                    byteObj = new Byte(strByte[i]);
                    Connection.txBuf.addElement(byteObj);
                }
            } else if (CHARACTER_BIT_MODE == 1) {
                for (int i = 0; i < (strLength * 2); i++) {
                    byteObj = new Byte(strByte[i]);
                    Connection.txBuf.addElement(byteObj);
                }
            }
            return true;
        } else {
            return false;
        }
    }

    /**
     * Performs a series of printing processes. <br><br>
     * Specifically, clearing the buffer by the side of a printer, 
     * outputing the contents of the text buffer to a communication port, 
     * acquiring the error kind and prompting it, waiting the end and so on. <br>
     * In addition, the setup of the communication port is performed at the time
     * of initialization. <br>
     * 
     * @return true if it succeed; false otherwise.
     */
    public boolean mpEscpPrint() {
        if (Connection.communicationStatus == CommunicationStatus.COMMUNICATION_STATUS_COMMUNICATED) {
            bluetoothConnection.printAndWait();
            return true;
        } else {
            return false;
        }
    }

    /**
     * Performs a series of uninitialization processes. <br><br>
     * Specifically, changing command mode to raster mode, acquiring the error
     * kind and prompting it, clearing the buffer by the side of a printer,
     * disconnecting Bluetooth connection, clearing transmitting buffer, waiting
     * the end and so on. <br>
     * 
     * @return true if it succeed; false otherwise.
     */
    public boolean mpEscpUninit() {
        bluetoothConnection.uninitializeAndWait();
        Connection.communicationStatus = CommunicationStatus.COMMUNICATION_STATUS_NO_COMMUNICATION;
        return true;
    }
}

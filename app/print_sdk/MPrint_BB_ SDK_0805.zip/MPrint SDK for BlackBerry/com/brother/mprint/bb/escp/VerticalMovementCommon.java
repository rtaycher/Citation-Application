package com.brother.mprint.bb.escp;

/**
 * Provides common commands for the vertical movement ESC/P commands. <br>
 * @author naoki
 */
public class VerticalMovementCommon extends EscpCommand{

    /**
     * Stores Page Feed command in the transmitting buffer. <br><br>
     * The Page Feed command is as follows. <br><br>
     * FF Page feed. <br>
     * [ASCII] FF <br>
     * [Decimal] 12 <br>
     * [Hexadecimal] 0C <br>
     * [Parameters] None <br>
     * [Description] <br>- Begins printing. <br>- This command prints all the characters and the commands input before this, and then clears all the texts. (Same as
     * ESC@.) <br>- Although the name of the command is "page feed", it should
     * be considered a "begin printing" command, and not used as a "page feed"
     * command. <br>- If the previously entered text crosses onto multiple
     * pages and the print position when the page was changed becomes the print
     * beginning (TOF position) in the vertical direction, and becomes the
     * beginning of line position in the horizontal direction. <br>- At that
     * time, the "specify auto-cancelling enlarged characters" commands using SO
     * and ESC SO are cancelled. <br>
     * <br>* To perform a page feed with each setting remaining as specified,
     * specify a (any) large position from the bottom margin position using ESC
     * J, ESC ( V or ESC (v. <br>
     * <br>
     * <img src="../../../../../resources/ff.bmp"> <br>
     * <br>
     */
    public void escpPageFeed() {
        byte[] buffer = { 0x0c };
        mpEscpCommand(buffer);
    }
}
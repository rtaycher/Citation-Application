package com.brother.mprint.bb.escp.commands;

import com.brother.mprint.bb.escp.BluetoothConnection;
import com.brother.mprint.bb.escp.EscpCommand;

/**
 * Provides ESC/P command for the paper formatting. <br>
 * @author naoki
 */
public class PaperFormatting extends EscpCommand{
    BluetoothConnection bluetoothConnection = BluetoothConnection.getInstance();

    /**
     * Stores Specify Page Format command with the parameters in the
     * transmitting buffer. <br><br>
     * The Specify Page Format command is as follows: <br><br>
     * ESC ( c Specify page format. <br>
     * [ASCII] ESC ( c nL nH tL tH bL bH <br>
     * [Decimal] 27 40 99 nL nH tL tH bL bH <br>
     * [Hexadecimal] 1B 28 63 nL nH tL tH bL bH <br>
     * [Parameters] nL = 4, nH = 0 <br>
     * (tL+tH*256) < (bL + bH * 256) <br>
     * Top margin < Bottom margin <br>
     * [Description] <br>- Specifies settings for the top and bottom margins.
     * <br>- This printer is designed specifically for A7-size paper, and the
     * physical printable area is 1180 dots (height) * 816 dots (width) with the
     * portrait orientation, or 816 dots (height) * 1180 dots (width) with the
     * landscape orientation. <br>
     * The top margin and bottom margin are specified in units of 1/300 inch (1
     * dot), based on the top edge of the physical printable area. <br>
     * (The left margin and right margin are based on the left side of the
     * physical printable area.) <br>
     * Top margin = tL + tH * 256 <br>
     * Bottom margin = bL + bH * 256 <br>- The top margin position is the TOF
     * in the vertical direction. <br>- Execute this command before entering
     * text. All text until then is cleared. <br>
     * <br>- If this code is specified, the top and bottom margins that were
     * previously specified are cancelled. <br>- The standard unit is not used.
     * <br>
     * 
     * @param topMargin Specifies the top margin. 
     * @param bottomMargin Specifies the bottom margin. 
     */
    public void escpSpecifyPageFormat(int topMargin, int bottomMargin) {
        byte[] buffer = { 0x1b, 0x28, 0x63, 0x04, 0x00,
                (byte) getnL(topMargin), (byte) getnH(topMargin), 
                (byte) getnL(bottomMargin), (byte) getnH(bottomMargin) };
        mpEscpCommand(buffer);
    }
}
package com.brother.mprint.bb.escp;

import java.util.Vector;

/**
 * This is the library class for Communication between BlackBerry and MPrint. <br>
 * @author oyoshida
 */
public class Connection implements Orientation, CommunicationStatus {

	/**
	 * Stores the Communication status. <br><br>
	 * The specification of communicationStatus is as follows: <br>
	 * <ul>
	 * <li>COMMUNICATED_ERROR
	 * <li>COMMUNICATION_LOCKED
	 * <li>NO_COMMUNICATION
	 * <li>COMMUNICATED
	 * </ul>
	 */
	public static int communicationStatus;

	/**
	 * Transmitting buffer. <br>
	 */
	public static Vector txBuf = new Vector();

	/**
	 * Stores the Orientation setting. <br><br>
	 * The specification of orientationSetting is as follows: <br>
	 * <ul>
	 * <li>ORIENTATION_PORTRAIT
	 * <li>ORIENTATION_LANDSCAPE
	 * </ul>
	 */
	public static int orientationSetting = Orientation.ORIENTATION_PORTRAIT;
}

package com.brother.mprint.bb.escp;

/**
 * Defines the fields for the alignmemt. <br>
 * @author oyoshida
 */
public interface Alignment {

	/**
	 * Predefined Left position for the alignment. <br>
	 */
	public static final int ALIGNMENT_LEFT = 0;

	/**
	 * Predefined Center position for the alignment. <br>
	 */
	public static final int ALIGNMENT_CENTER = 1;

	/**
	 * Predefined Right position for the alignment. <br>
	 */
	public static final int ALIGNMENT_RIGHT = 2;

}
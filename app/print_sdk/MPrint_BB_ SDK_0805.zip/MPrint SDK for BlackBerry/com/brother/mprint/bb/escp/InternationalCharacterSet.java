package com.brother.mprint.bb.escp;

/**
 * Defines the fields for the international character set. <br>
 * @author oyoshida
 */
public interface InternationalCharacterSet {

	/**
	 * Predefined United States used for the international character set. <br>
	 */
	public static final int INTERNATIONAL_CHARACTER_SET_UNITED_STATES = 0;

	/**
	 * Predefined France used for the international character set. <br>
	 */
	public static final int INTERNATIONAL_CHARACTER_SET_FRANCE = 1;

	/**
	 * Predefined Germany used for the international character set. <br>
	 */
	public static final int INTERNATIONAL_CHARACTER_SET_GERMANY = 2;

	/**
	 * Predefined Britain used for the international character set. <br>
	 */
	public static final int INTERNATIONAL_CHARACTER_SET_BRITAIN = 3;

	/**
	 * Predefined Denmark used for the international character set. <br>
	 */
	public static final int INTERNATIONAL_CHARACTER_SET_DENMARK = 4;

	/**
	 * Predefined Sweden used for the international character set. <br>
	 */
	public static final int INTERNATIONAL_CHARACTER_SET_SWEDEN = 5;

	/**
	 * Predefined Italy used for the international character set. <br>
	 */
	public static final int INTERNATIONAL_CHARACTER_SET_ITALY = 6;

	/**
	 * Predefined Spain used for the international character set. <br>
	 */
	public static final int INTERNATIONAL_CHARACTER_SET_SPAIN = 7;

	/**
	 * Predefined Japan used for the international character set. <br>
	 */
	public static final int INTERNATIONAL_CHARACTER_SET_JAPAN = 8;

	/**
	 * Predefined Norway used for the international character set. <br>
	 */
	public static final int INTERNATIONAL_CHARACTER_SET_NORWAY = 9;

	/**
	 * Predefined Denmark 2 used for the international character set. <br>
	 */
	public static final int INTERNATIONAL_CHARACTER_SET_DENMARK2 = 10;

	/**
	 * Predefined Spain 2 used for the international character set. <br>
	 */
	public static final int INTERNATIONAL_CHARACTER_SET_SPAIN2 = 11;

	/**
	 * Predefined Latin America used for the international character set. <br>
	 */
	public static final int INTERNATIONAL_CHARACTER_SET_LATIN_AMERICA = 12;

	/**
	 * Predefined Korea used for the international character set. <br>
	 */
	public static final int INTERNATIONAL_CHARACTER_SET_KOREA = 13;

	/**
	 * Predefined Legal used for the international character set. <br>
	 */
	public static final int INTERNATIONAL_CHARACTER_SET_LEGAL = 64;

}
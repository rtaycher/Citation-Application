package com.brother.mprint.bb.escp.commands;

import com.brother.mprint.bb.escp.BluetoothConnection;
import com.brother.mprint.bb.escp.VerticalMovementCommon;

/**
 * Provides ESC/P command for the vertical movements. <br>
 * @author naoki
 */
public class VerticalMovement extends VerticalMovementCommon{
    BluetoothConnection bluetoothConnection = BluetoothConnection.getInstance();

    /**
     * Stores Line Feed command in the transmitting buffer. <br><br>
     * The Line Feed command is as follows: <br><br>
     * LF Line feed. <br>
     * [ASCII] LF <br>
     * [Decimal] 10 <br>
     * [Hexadecimal] 0A <br>
     * [Parameters] None <br>
     * [Description] <br>- Performs a line feed by the amount specified by the
     * "specify line feed amount" commands (ESC 0, ESC 2, ESC 3, and ESC A).
     * <br>- The print position is at the beginning of the next line. <br>-
     * The default setting is a line feed amount of 48 dots. <br>- If CR is
     * immediately after LF, CR becomes invalid. <br>- The "specify
     * auto-cancelling enlarged characters" commands using SO and ESC SO are
     * cancelled. <br>
     */
    public void escpLineFeed() {
        byte[] buffer = { 0x0a };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Forward Paper Feed command with the parameter in the transmitting
     * buffer. <br><br>
     * The Forward Paper Feed command is as follows: <br><br>
     * ESC J Forward paper feed. <br>
     * [ASCII] ESC J n <br>
     * [Decimal] 27 74 n <br>
     * [Hexadecimal] 1B 4A n <br>
     * [Parameters] 0 <= n <= 255 <br>
     * [Description] <br>
     * - Ends input of the current line, and moves the vertical print position forward n/300 inch (1 dot). <br>
     * - If the data extends past the bottom margin setting, printing begins. <br>
     * - The print position for the next line becomes the end position for the current line in a left alignment. (The horizontal position does not move to the left margin.) <br>
     * In a right alignment or center alignment, the horizontal position moves to the beginning position of the line. <br>
     * - The "specify auto-cancelling enlarged characters" commands using SO and ESC SO are cancelled. <br>
     * <br>
     * <img src="../../../../../../resources/esc_j.bmp"> <br>
     * <br>
     * 
     * @param dots Specifies the forward paper feed. 
     */
    public void escpForwardPaperFeed(int dots) {
        if (0 <= dots || dots <= 255) {
            byte[] buffer = { 0x1b, 0x4a, (byte) dots };
            mpEscpCommand(buffer);
        }
    }

    /**
     * Stores Specify Vertical Tab Position command with the parameters in the
     * transmitting buffer. <br><br>
     * The Specify Vertical Tab Position command is as follows: <br><br>
     * ESC B Specify vertical tab position. <br>
     * [ASCII] ESC B [n]k NUL <br>
     * [Decimal] 27 66 [n]k 0 <br>
     * [Hexadecimal] 1B 42 [n]k 00h <br>
     * [Parameters] 1 <= n <= 255 <br>
     * 0 <= k <= 16 <br>
     * [Description] <br>- The vertical tab position is set at the position of
     * the line feed amount when the vertical tab is specified*n from the top
     * margin position. <br>- Enter n in ascending order, and end the setting
     * with NUL. <br>- If any n value is smaller than the value before it, the
     * tab setting is finished. <br>- A maximum of 16 vertical tab positions
     * can be specified. <br>- Use ESC B NUL to cancel all vertical tab
     * positions. <br>- Vertical tab positions can be specified, regardless of
     * the bottom margin position setting. However, vertical tab positions
     * outside of the print area (past the bottom margin position) are invalid,
     * and they become valid when they enter the print area due to a change in
     * the top margin setting or the bottom margin setting. <br>- Use VT to
     * move to the vertical tab position. <br>- When changing the vertical tab
     * positions, specify all positions again. <br>- If the top margin is
     * moved, the vertical tab positions are also moved the amount that the top
     * margin is moved. <br>- The vertical tab setting position does not change
     * if the line feed amount is changed after the vertical tab position is
     * specified. <br>- If VT is performed while not vertical tabs are
     * specified, the same operation as CR is performed. <br>
     * 
     * @param verticalTabPosition Specifies the vertical tab positions. 
     */
    public void escpSpecifyVerticalTabPosition(int[] verticalTabPosition) {
        byte[] buffer = new byte[verticalTabPosition.length + 3];
        buffer[0] = 0x1b;
        buffer[1] = 0x42;
        for (int i = 0; i < verticalTabPosition.length; i++) {
            buffer[i + 2] = (byte) verticalTabPosition[i];
        }
        buffer[verticalTabPosition.length + 2] = 0x00;
        mpEscpCommand(buffer);
    }

    /**
     * Stores Apply Vertical Tab command in the transmitting buffer. <br><br>
     * The Apply Vertical Tab command is as follows: <br><br>
     * VT Apply vertical tab. <br>
     * [ASCII] VT <br>
     * [Decimal] 11 <br>
     * [Hexadecimal] 0B <br>
     * [Parameters] None <br>
     * [Description] <br>- Moves the print position from the position where VT
     * was entered to the next nearest vertical tab position below. <br>- The
     * next horizontal print position is the beginning of the line. <br>- If
     * the next vertical tab position extends past the bottom margin, or if
     * there are no vertical tab positions after the current position, VT is
     * performed as if it is FF (moves to the TOF position of the next page).
     * <br>
     * <br>
     * <img src="../../../../../../resources/vt.bmp"> <br>
     * <br>- When all vertical tab positions are cancelled by an initialization
     * or ESC B NUL, the same operation as CR is performed. <br>- The "specify
     * auto-cancelling enlarged characters" commands using SO and ESC SO are
     * cancelled. <br>
     * [Example] Specifying vertical tabs on lines 4, 8, 12 and 16 <br>
     * Code <br>
     * 
     * <pre>
     *          ESC B 04h 08h 0Ah 10h 00h
     * </pre>
     */
    public void escpApplyVerticalTab() {
        byte[] buffer = { 0x0b };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Specify Absolute Vertical Position command with the parameters in
     * the transmitting buffer. <br><br>
     * The Specify Absolute Vertical Position command is as follows: <br><br>
     * ESC ( V Specify absolute vertical position. <br>
     * [ASCII] ESC ( V nL nH mL mH <br>
     * [Decimal] 27 40 86 nL nH mL mH <br>
     * [Hexadecimal] 1B 28 56 nL nH mL mH <br>
     * [Parameters] nL = 2 <br>
     * nH = 0 <br>
     * 0 <= mL <= 255 <br>
     * 0 <= mH <= 127 <br>
     * [Description] <br>- Specifies the vertical print position as an absolute
     * position from the top margin position. <br>
     * Vertical position = mL + mH * 256 + Top margin <br>- The absolute
     * vertical position is measured from the top margin position at the time.
     * <br>- If a position extending past the bottom margin is specified,
     * printing begins. <br>- There are no limitations on the movement amount
     * in the opposite direction (up) from the current position. <br>- The
     * print position for the next line becomes the end position for the current
     * line in a left alignment. (The horizontal position does not move to the
     * left margin.) <br>
     * In a right alignment or center alignment, the horizontal position moves
     * to the beginning position of the line. <br>- The "specify
     * auto-cancelling enlarged characters" commands using SO and ESC SO are
     * cancelled. <br>
     * <br>
     * <img src="../../../../../../resources/esc_(v.bmp"> <br>
     * <br>
     * 
     * @param yPosition Specifies the absolute vertical position. 
     */
    public void escpSpecifyAbsoluteVerticalPosition(int yPosition) {
        byte[] buffer = { 0x1b, 0x28, 0x56, 0x02, 0x00, (byte) getnL(yPosition), (byte) getnH(yPosition) };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Specify Relative Vertical Position command with the parameters in
     * the transmitting buffer. <br><br>
     * The Specify Relative Vertical Position command is as follows: <br><br>
     * ESC ( v Specify relative vertical position. <br>
     * [ASCII] ESC ( v nL nH mL mH <br>
     * [Decimal] 27 40 118 nL nH mL mH <br>
     * [Hexadecimal] 1B 28 76 nL nH mL mH <br>
     * [Parameters] nL = 2 <br>
     * nH = 0 <br>
     * 0 <= mL <= 255 <br>
     * 0 <= mH <= 127 <br>
     * -16384 <= (mL + mH*256) <= 16383 <br>
     * [Description] <br>- Specifies the vertical print position as a relative
     * position from the current position. <br>
     * Vertical position after movement = mL + mH * 256 + Current position <br>-
     * The specified value for moving up is represented as a 2's complement, and
     * is basically determined by the following equation. <br>
     * mL + mH * 256 = 65536 - Actual amount moved <br>- A setting for movement
     * up from the top margin is ignored. <br>- If a position extending past
     * the bottom margin is specified, printing begins. <br>- The print
     * position for the next line becomes the end position for the current line
     * in a left alignment. (The horizontal position does not move to the left
     * margin.) <br>
     * In a right alignment or center alignment, the horizontal position moves
     * to the beginning position of the line. <br>- The "specify
     * auto-cancelling enlarged characters" commands using SO and ESC SO are
     * cancelled. <br>
     * 
     * @param yPosition Specify the relative vertical position. 
     */
    public void escpSpecifyRelativeVerticalPosition(int yPosition) {
        byte[] buffer = { 0x1b, 0x28, 0x76, 0x02, 0x00, (byte) getnL(yPosition), (byte) getnH(yPosition) };
        mpEscpCommand(buffer);
    }
}
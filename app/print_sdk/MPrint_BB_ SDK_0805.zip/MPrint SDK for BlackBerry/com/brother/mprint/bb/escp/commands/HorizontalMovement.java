package com.brother.mprint.bb.escp.commands;

import com.brother.mprint.bb.escp.BluetoothConnection;
import com.brother.mprint.bb.escp.EscpCommand;

/**
 * Provides ESC/P command for the horizontal movements. <br>
 * @author naoki
 */
public class HorizontalMovement extends EscpCommand {
    BluetoothConnection bluetoothConnection = BluetoothConnection.getInstance();

    /**
     * Stores Specify Left Margin command with the parameter in the transmitting
     * buffer. <br><br>
     * The Specify Left Margin command is as follows: <br><br>
     * ESC l Specify left margin. <br>
     * [ASCII] ESC l n <br>
     * [Decimal] 27 108 n <br>
     * [Hexadecimal] 1B 6C n <br>
     * [Parameters] 0 <= n <= 255 <br>
     * 0 <= Left margin < Right margin <br><br>
     * [Description] <br>- The left margin and right margin are based on the
     * left side of the physical printable area. <br>- The area from the left
     * side of the physical printable area to the specified number of columns is
     * set as an unprinted area. The left margin position is the right side of
     * the specified column. (character width*n) <br>- With the portrait
     * orientation, specify a value within the range 0 <= (character width*n) <=
     * 816. <br>- With the landscape orientation, specify a value within the
     * range 0 <= (character width*n) <= 1180. <br> Any setting outside of
     * this range is ignored. <br>- The area from the left side (1st column) to
     * the nth column is set as an unprinted area. <br> The position of the
     * character width * n from the left side when the left margin is specified is
     * the left margin position. <br>
     * The character width when the left margin is specified includes the
     * settings for the "specify character spacing", "specify spacing for
     * full-width characters", or "specify spacing for half-width characters"
     * commands. In addition, when the 10 cpi (30 dots), 12 cpi (25 dots), or
     * 14.29 cpi (21 dots) pitch or the "specify reduced characters" or "specify
     * double-width characters" command is set, that character width is
     * considered as the unit. <br>
     * However, this command doesn't correspond to the amount to which the width of the character extends by the character styles. <br>
     * <br>
     * <img src="../../../../../../resources/esc_i.bmp"> <br>
     * <br>- The horizontal printing position moves to the left margin
     * position. <br>- If the left margin setting is not at the beginning of
     * the line, the left margin is set after a line feed is performed. <br>
     * In addition, the beginning of the line indicates the left margin position
     * for a left alignment and, for a right or center alignment, it indicates
     * that no image or characters are entered in that line. <br>- The left
     * margin position does not change if the character width is changed after
     * the left margin is specified. <br>- A left margin setting where the left
     * margin position is to the right of the right margin position is ignored.
     * <br>- The left margin should be set at least one column (10 cpi (30
     * dots)) less than the right margin. <br>
     * (Ignored if (character width * n) > (right margin - 30 dots) when left margin is specified.) <br>
     * - If the difference between the right and left
     * margin positions does not even allow for one character, that character is
     * ignored. <br>- If the proportional pitch is specified using the ESC p
     * command, a character width of 10 cpi (30 dots) is applied. <br>
     * [Example] The left margin is set to column 3.<br>
     * Code <br>
     * 
     * <pre>
     *       ABC CR ESC l 03h EFGHIJ FF
     * </pre>
     * 
     * Print result <br>
     * 
     * <pre>
     *     | ABC
     *     |    EFGHIJ
     * </pre>
     * 
     * @param leftMargin Specifies the left margin. 
     */
    public void escpSpecifyLeftMargin(int leftMargin) {
        if (0 <= leftMargin && leftMargin <= 255) {
            byte[] buffer = { 0x1b, 0x6c, (byte) leftMargin };
            mpEscpCommand(buffer);
        }
    }

    /**
     * Stores Specify Right Margin command with the parameter in the
     * transmitting buffer. <br><br>
     * The Specify Right Margin command is as follows: <br><br>
     * ESC Q Specify right margin. <br>
     * [ASCII] ESC Q n <br>
     * [Decimal] 27 81 n <br>
     * [Hexadecimal] 1B 51 n <br>
     * [Parameters] 1 <= n <= 255 <br>
     * Left margin < Character width when right margin is specified*n <=
     * Printable area <br>
     * [Description] <br>- The left margin and right margin are based on the
     * left side of the physical printable area. <br>- The left margin position
     * is the right side of the specified column. (character width*n) * See Specify Left Margin. <br>-
     * With the portrait orientation, specify a value within the range 1 <=
     * (character width*n) <= 816. <br>- With the landscape orientation,
     * specify a value within the range 1 <= (character width*n) <= 1180. <br>-
     * Any setting outside of this range is ignored. <br>- The following range
     * must be observed: Left margin <= Print area < Right margin. <br>- The
     * position of the character width * n from the left side when the right margin is specified 
     * is the right margin position. <br>
     * The character width when the right margin is specified includes the
     * settings for the "specify character spacing", "specify spacing for
     * full-width characters", or "specify spacing for half-width characters"
     * commands. In addition, when the 10 cpi (30 dots), 12 cpi (25 dots), or
     * 14.29 cpi (21 dots) pitch or the "specify reduced characters" or "specify
     * double-width characters" command is set, that character width is
     * considered as the unit. <br>
     * However, this command doesn't correspond to the amount to which the width of the character extends by the character styles. <br>
     * - The horizontal printing position moves to the left margin
     * position. <br>- If a right margin is set excluding the head of the line, the setting of a right margin becomes effective after it changes line. <br>
     * In addition, the beginning of the line indicates the left margin position
     * for a left alignment and, for a right or center alignment, it indicates
     * that no image or characters are entered in that line. <br>- The right
     * margin position does not change if the character width is changed after
     * the right margin is specified. <br>- A right margin setting where the
     * right margin position is to the left of the left margin position is
     * ignored. <br>- The right margin should be set at least one column (10
     * cpi (30 dots)) more than the left margin. <br>
     * (Ignored if (character width when right margin is specified*n) < (left
     * margin + 30 dots).) <br>- If the difference between the right and left
     * margin positions does not even allow for one character, that character is
     * ignored. <br>- If the proportional pitch is specified using the ESC p
     * command, a character width of 10 cpi (30 dots) is applied. <br>
     * 
     * @param rightMargin Specifies the right margin. 
     */
    public void escpSpecifyRightMargin(int rightMargin) {
        if (1 <= rightMargin && rightMargin <= 255) {
            byte[] buffer = { 0x1b, 0x51, (byte) rightMargin };
            mpEscpCommand(buffer);
        }
    }

    /**
     * Stores Carriage Return command in the transmitting buffer. <br><br>
     * The Carriage Return command is as follows: <br><br>
     * CR Carriage return. <br>
     * [ASCII] CR <br>
     * [Decimal] 13 <br>
     * [Hexadecimal] 0D <br>
     * [Parameters] None <br>
     * [Description] <br>- Concludes the input of one line, and waits for input
     * of the second line. <br>- The next print position is the beginning of
     * the next line. <br>- An LF command immediately after CR is ignored. <br>-
     * The "specify auto-cancelling enlarged characters" commands in ANK mode
     * using SO and ESC SO are cancelled. <br>
     */
    public void escpCarriageReturn() {
        byte[] buffer = { 0x0d };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Specify Horizontal Tab Position command with the parameters in the
     * transmitting buffer. <br><br>
     * The Specify Horizontal Tab Position command is as follows: <br><br>
     * ESC D Specify horizontal tab position. <br>
     * [ASCII] ESC D [n]k NUL <br>
     * [Decimal] 27 68 [n]k 0 <br>
     * [Hexadecimal] 1B 44 [n]k 00h <br>
     * [Parameters] 1 <= n <= 255, 0 <= k <= 32 <br>
     * [Description] <br>- The horizontal tab position is set at the position of the character width * n from the left margin position 
     * when the horizontal tab is specified. <br>
     * - Enter n in ascending order, and end the
     * setting with NUL. <br>- If any n value is smaller than the value before
     * it, the tab setting is finished. <br>- The horizontal tab setting
     * position does not change if the character width is changed after the
     * horizontal tab position is specified. <br>- All horizontal tab positions
     * are cancelled with ESC D NUL. <br>- If the left margin is moved, the
     * horizontal tab positions are also moved accordingly. <br>- Up to 32
     * horizontal tab positions can be specified. However, horizontal tab
     * positions extending past the right margin are invalid, and they become
     * valid when they enter the print area due to a change in the right margin
     * setting or the left margin setting. <br>- The character width when
     * horizontal tabs are specified includes the settings for the "specify
     * character spacing", "specify spacing for full-width characters", or
     * "specify spacing for half-width characters" commands. In addition, when
     * the 10 cpi, 12 cpi, or 14.29 cpi pitch or the "specify reduced
     * characters" or "specify double-width characters" command is set, that
     * character width is considered as the unit. <br>- If the proportional
     * pitch is specified using the ESC p command, a horizontal tab position is
     * set at 10 cpi (30 dots). <br>- When the unit is turned on, a horizontal
     * tab position is specified at every eight columns with an equivalence of
     * 10 cpi. <br>
     * The horizontal tab position does not change if the character width is
     * changed before the horizontal tab position is specified. <br>
     * 
     * @param horizontalTabPosition Specifies the horizontal tab positions. 
     */
    public void escpSpecifyHorizontalTabPosition(int[] horizontalTabPosition) {
        byte[] buffer = new byte[horizontalTabPosition.length + 3];
        buffer[0] = 0x1b;
        buffer[1] = 0x44;
        for (int i = 0; i < horizontalTabPosition.length; i++) {
            buffer[i + 2] = (byte) horizontalTabPosition[i];
        }
        buffer[horizontalTabPosition.length + 2] = 0x00;
        mpEscpCommand(buffer);
    }

    /**
     * Stores Apply Horizontal Tab command in the transmitting buffer. <br><br>
     * The Apply Horizontal Tab command is as follows: <br><br>
     * HT Apply horizontal tab. <br>
     * [ASCII] HT <br>
     * [Decimal] 9 <br>
     * [Hexadecimal] 09 <br>
     * [Parameters] None <br>
     * [Description] <br>- Moves the horizontal print position from the
     * position where HT was entered to the next nearest horizontal tab position
     * to the right. <br>- If there are no horizontal tab positions to the
     * right of the current horizontal position, or if the next horizontal tab
     * position extends past the right margin, HT is ignored. <br>- If
     * underlining is specified, the space between the current position and the
     * next horizontal tab position is not underlined. <br>- When the unit is
     * turned on, a horizontal tab position is specified at every eight columns
     * with an equivalence of 10 cpi. <br>
     * The horizontal tab position does not change if the character width is
     * changed before the horizontal tab position is specified. <br>
     * <br>
     * <img src="../../../../../../resources/esc_d.bmp"> <br>
     * <br>- This command is available only with left alignment. <br>
     * <br>
     * [Example] Specifying a horizontal tab at columns 4, 8 and 12, and
     * applying a horizontal tab <br>
     * Code <br>
     * 
     * <pre>
     *       ESC D 04h 08h 0Ah 00h
     *       123456789012 CR A HT B HT C HT D FF
     * </pre>
     * 
     * Print result <br>
     * 
     * <pre>
     *    |  123456789012
     *    |  A   B   C   D
     * </pre>
     */
    public void escpApplyHorizontalTab() {
        byte[] buffer = { 0x09 };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Specify Absolute Horizontal Position command with the parameters
     * in the transmitting buffer. <br><br>
     * The Specify Absolute Horizontal Position command is as follows: <br><br>
     * ESC $ Specify absolute horizontal position. <br>
     * [ASCII] ESC $ n1 n2 <br>
     * [Decimal] 27 36 n1 n2 <br>
     * [Hexadecimal] 1B 24 n1 n2 <br>
     * [Parameters] 0 <= n1 <= 255 , 0 <= n2 <= 255 <br>
     * [Description] <br>- Specifies an absolute position in dots for the print
     * position for the next data. <br>- When specifying an absolute position,
     * the next print position is specified in dots from the left margin. <br>-
     * n1 and n2 represent the number of dots from the left margin. (No. of dots =
     * n1 + 256 * n2) <br>- The spacing of 1 dot is calculated as 1/300 inch.
     * <br>- The maximum number of dots that can be specified by n1 and n2 is
     * 815 dots in the portrait orientation and 1179 dots in the landscape
     * orientation. <br>- This command is available only with left alignment.
     * <br>
     * 
     * @param xPosition Specifies the absolute horizontal position. 
     */
    public void escpSpecifyAbsoluteHorizontalPosition(int xPosition) {
        byte[] buffer = { 0x1b, 0x24, (byte) getnL(xPosition), (byte) getnH(xPosition) };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Specify Relative Horizontal Position command with the parameters
     * in the transmitting buffer. <br><br>
     * The Specify Relative Horizontal Position command is as follows: <br><br>
     * ESC \ Specify relative horizontal position. <br>
     * [ASCII] ESC \ n1 n2 <br>
     * [Decimal] 27 92 n1 n2 <br>
     * [Hexadecimal] 1B 5C n1 n2 <br>
     * [Parameters] 0 <=n1 <=255, 0 <=n2 <=255 <br>
     * [Description] <br>- Specifies the horizontal print position as a
     * relative position in dots from the current position. <br>- When
     * specifying a relative position, the next print position is specified in
     * dots from the current position. <br>- n1 and n2 represent the number of
     * dots from the current position. (No. of dots = n1 + 256 * n2) <br>- The
     * spacing of 1 dot is calculated as 1/300 inch. <br>- Left margin position <=
     * horizontal position after moving < Right margin position <br>
     * Horizontal position after moving = n1 + n2 * 256 <br>- The specified
     * value for moving to the left is represented as a 2's complement, and is
     * basically determined by the following equation. <br>
     * n1 + n2 * 256 = 65536 - Actual amount moved <br>- This command is
     * available only with left alignment. <br>
     * 
     * @param xPosition Specifies the relative horizontal position. 
     */
    public void escpSpecifyRelativeHorizontalPosition(int xPosition) {
        byte[] buffer = { 0x1b, 0x5c, (byte) getnL(xPosition), (byte) getnH(xPosition) };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Specify Alignment command with the parameter in the transmitting
     * buffer. <br><br>
     * The Specify Alignment command is as follows: <br><br>
     * ESC a Specify alignment. <br>
     * [ASCII] ESC a n <br>
     * [Decimal] 27 97 n <br>
     * [Hexadecimal] 1B 61 n <br>
     * [Parameters] 0 <= n <= 3 or "0" <= n <= "3" <br>
     * [Description] <br>- Aligns and prints the following data according to
     * the value of n as described below. <br>
     * If n=0, specifies a left alignment. <br>
     * If n=1, specifies a center alignment. <br>
     * If n=2, specifies a right alignment. <br>
     * If n=3, nothing is applied. <br>- The default setting is n=0. <br>-
     * Data is aligned by entering a CR, LF or FF code between the left and
     * right margins or by printing a full buffer. <br>- If the alignment
     * setting is not at the beginning of the line, the alignment is set after a
     * line feed is performed. <br>
     * In addition, the beginning of the line indicates the left margin position
     * for a left alignment and, for a right or center alignment, it indicates
     * that no image or characters are entered in that line. <br>- HT, ESC \
     * and ESC $ are ignored if n=1 or 2.<br>
     * [Example] Center alignment of text <br>
     * Code <br>
     * 
     * <pre>
     *       12345678901234567 CR ESC a 1 ABC FF
     * </pre>
     * 
     * Print result <br>
     * 
     * <pre>
     *     | 12345678901234567 |
     *     |        ABC        |
     * </pre>
     * 
     * @param alignment Specifies the alignment. Please choose from ALIGNMENT_ fields. 
     */
    public void escpSpecifyAlignment(int alignment) {
        if (0 <= alignment && alignment <= 3) {
            byte[] buffer = { 0x1b, 0x61, (byte) alignment };
            mpEscpCommand(buffer);
        }
    }
}
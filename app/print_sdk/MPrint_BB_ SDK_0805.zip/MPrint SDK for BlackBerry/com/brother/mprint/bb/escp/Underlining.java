package com.brother.mprint.bb.escp;

/**
 * Defines the fields for the underlining. <br>
 * @author oyoshida
 */
public interface Underlining {

	/**
	 * Predefined Cancelled used for the underlining. <br>
	 */
	public static final int UNDERLINING_CANCELLED = 0;

	/**
	 * Predefined One Dot used for the underlining. <br>
	 */
	public static final int UNDERLINING_ONE_DOT = 1;

	/**
	 * Predefined Two Dots used for the underlining. <br>
	 */
	public static final int UNDERLINING_TWO_DOTS = 2;

	/**
	 * Predefined Three Dots used for the underlining. <br>
	 */
	public static final int UNDERLINING_THREE_DOTS = 3;

	/**
	 * Predefined Four Dots used for the underlining. <br>
	 */
	public static final int UNDERLINING_FOUR_DOTS = 4;

}
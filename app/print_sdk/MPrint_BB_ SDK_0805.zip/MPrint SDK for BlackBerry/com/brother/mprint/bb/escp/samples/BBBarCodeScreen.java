package com.brother.mprint.bb.escp.samples;

import com.brother.mprint.bb.escp.sdk.BasicPrinting;
import com.brother.mprint.bb.escp.CommunicationPort;
import com.brother.mprint.bb.escp.Connection;
import com.brother.mprint.bb.escp.commands.Advanced;

import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.component.LabelField;
import net.rim.device.api.ui.component.ObjectChoiceField;
import net.rim.device.api.ui.component.EditField;
import net.rim.device.api.ui.component.ButtonField;
import net.rim.device.api.ui.container.MainScreen;
import net.rim.device.api.system.Characters;

class BBBarCodeScreen extends MainScreen {
//  Ticker ticker;
    ObjectChoiceField objectChoiceField0;
    ObjectChoiceField objectChoiceField1;
    ObjectChoiceField objectChoiceField2;
    ObjectChoiceField objectChoiceField3;
    LabelField labelField0;
    LabelField labelField1;
    LabelField labelField2;
    LabelField labelField3;
    LabelField labelField4;
    LabelField blank;
    EditField editField;
    LabelField select;
    ButtonField printButton;

    public BBBarCodeScreen() {
        blank = new LabelField("");
        add(blank);
//      ticker = new Ticker("Brother MPrint Series MW-100 / MW-120 / MW-140BT Now on sale! MW-140BT Type-E Coming soon!");
//      setTicker(ticker);
        select = new LabelField("*** Select Bar Codes ***");
        add(select);
        blank = new LabelField("");
        add(blank);
        labelField0 = new LabelField("Standard");
        add(labelField0);
        objectChoiceField0 = new ObjectChoiceField();
        String[] stringObjectChoiceField0 = { "CODE39", "INTERLEAVED 2 OF 5", "EAN-8, EAN-13, UPC-A", "UPC-E", "CODABAR" };
        objectChoiceField0.setChoices(stringObjectChoiceField0);
        add(objectChoiceField0);
        blank = new LabelField("");
        add(blank);
        labelField1 = new LabelField("Characters");
        add(labelField1);
        objectChoiceField1 = new ObjectChoiceField();
        String[] stringObjectChoiceField1 = { "OFF", "ON" };
        objectChoiceField1.setChoices(stringObjectChoiceField1);
        add(objectChoiceField1);
        blank = new LabelField("");
        add(blank);
        labelField2 = new LabelField("Height (mm)");
        add(labelField2);
        objectChoiceField2 = new ObjectChoiceField();
        String[] stringObjectChoiceField2 = { "5", "10", "15", "20", "25", "30" };
        objectChoiceField2.setChoices(stringObjectChoiceField2);
        add(objectChoiceField2);
        blank = new LabelField("");
        add(blank);
        labelField3 = new LabelField("Width");
        add(labelField3);
        objectChoiceField3 = new ObjectChoiceField();
        String[] stringObjectChoiceField3 = { "extra small", "small", "medium", "large" };
        objectChoiceField3.setChoices(stringObjectChoiceField3);
        add(objectChoiceField3);
        blank = new LabelField("");
        add(blank);
        labelField4 = new LabelField("BarCode Data");
        add(labelField4);
        editField = new EditField("", "", 100, EditField.FILTER_NUMERIC);
        add(editField);
        printButton = new ButtonField("Print...");
        add(printButton);
    }

    public boolean trackwheelClick(int status, int time)
    {
        if(!super.trackwheelClick(status, time)) {
            Field field = this.getLeafFieldWithFocus();
            if (field.equals(printButton)) {
                PrintThread printThread = new PrintThread();
                printThread.start();
                return true;
            }
        }
        return false;
    }

    public boolean keyChar(char key, int status, int time) {
        boolean retval = false;
        switch (key) {
            case Characters.ESCAPE:
                close();
                retval = true;
                break;
            }
        return retval;
    }

    class PrintThread extends Thread implements CommunicationPort {
        Advanced advanced;
        BasicPrinting basicPrinting;
        String Str_p[];
        int iType;
        int iNumber;
        int iHeight;
        int iWidth;
        String sData;
        int[] iData;
        public void run() {
            advanced = new Advanced();
            basicPrinting = BasicPrinting.getInstance();            
            Str_p = new String[4];
            iType = 0;
            iNumber = 0;
            iHeight = 0;
            iWidth = 0;
            sData = new String();

            Str_p[0] = (objectChoiceField0.getChoice(objectChoiceField0.getSelectedIndex())).toString();
            Str_p[1] = (objectChoiceField1.getChoice(objectChoiceField1.getSelectedIndex())).toString();
            Str_p[2] = (objectChoiceField2.getChoice(objectChoiceField2.getSelectedIndex())).toString();
            Str_p[3] = (objectChoiceField3.getChoice(objectChoiceField3.getSelectedIndex())).toString();
            iType = objectChoiceField0.getSelectedIndex();
            iNumber = objectChoiceField1.getSelectedIndex();
            if(objectChoiceField2.getSelectedIndex() == 0)
            {
                iHeight = 60;
            }
            else if(objectChoiceField2.getSelectedIndex() == 1)
            {
                iHeight = 120;
            }
            else if(objectChoiceField2.getSelectedIndex() == 2)
            {
                iHeight = 180;
            }
            else if(objectChoiceField2.getSelectedIndex() == 3)
            {
                iHeight = 240;
            }
            else if(objectChoiceField2.getSelectedIndex() == 4)
            {
                iHeight = 300;
            }
            else if(objectChoiceField2.getSelectedIndex() == 5)
            {
                iHeight = 360;
            }
            iWidth = objectChoiceField3.getSelectedIndex();
            sData = new String(editField.getText());
            iData = new int[sData.length()];
            for (int i = 0; i < sData.length(); i++) {
                iData[i] = (Integer.valueOf(sData.substring(i, i + 1))).intValue();
            }

            basicPrinting.mpEscpInit(CommunicationPort.COMMUNICATION_PORT_BLUETOOTH,Connection.orientationSetting);
            basicPrinting.mpEscpPositionCtrl(1, 100);
            basicPrinting.mpEscpFormatCtrl(0, 187, 0);
            basicPrinting.mpEscpOutChar("BarCodes Sample");
            basicPrinting.mpEscpPositionCtrl(0, 260);
            basicPrinting.mpEscpPositionCtrl(100, 260);
            basicPrinting.mpEscpFormatCtrl(0, 27, 0);
            basicPrinting.mpEscpOutChar("Standard");
            basicPrinting.mpEscpPositionCtrl(350, 260);
            basicPrinting.mpEscpFormatCtrl(0, 27, 0);
            basicPrinting.mpEscpOutChar(Str_p[0]);
            basicPrinting.mpEscpPositionCtrl(100, 380);
            basicPrinting.mpEscpFormatCtrl(0, 27, 0);
            basicPrinting.mpEscpOutChar("Characters");
            basicPrinting.mpEscpPositionCtrl(350, 380);
            basicPrinting.mpEscpFormatCtrl(0, 27, 0);
            basicPrinting.mpEscpOutChar(Str_p[1]);
            basicPrinting.mpEscpPositionCtrl(100, 500);
            basicPrinting.mpEscpFormatCtrl(0, 27, 0);
            basicPrinting.mpEscpOutChar("Height");
            basicPrinting.mpEscpPositionCtrl(350, 500);
            basicPrinting.mpEscpFormatCtrl(0, 27, 0);
            basicPrinting.mpEscpOutChar(Str_p[2] + "mm");
            basicPrinting.mpEscpPositionCtrl(100, 620);
            basicPrinting.mpEscpFormatCtrl(0, 27, 0);
            basicPrinting.mpEscpOutChar("Width");
            basicPrinting.mpEscpPositionCtrl(350, 620);
            basicPrinting.mpEscpFormatCtrl(0, 27, 0);
            basicPrinting.mpEscpOutChar(Str_p[3]);
            basicPrinting.mpEscpPositionCtrl(1, 740);
            advanced.escpBarCode(iType, iNumber, iHeight, iWidth, iData);
            basicPrinting.mpEscpPrint();
            basicPrinting.mpEscpUninit();
        }
    }
}

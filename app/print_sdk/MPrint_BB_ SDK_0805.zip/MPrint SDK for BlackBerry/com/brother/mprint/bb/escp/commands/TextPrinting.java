package com.brother.mprint.bb.escp.commands;

import com.brother.mprint.bb.escp.EscpCommand;

/**
 * Provides ESC/P command for the text printing. <br>
 * @author naoki
 */
public class TextPrinting extends EscpCommand{

    /**
     * Stores Apply Italic Style command in the transmitting buffer. <br><br>
     * The Apply Italic Style command is as follows: <br><br>
     * ESC 4 Apply italic style. <br>
     * [ASCII] ESC 4 <br>
     * [Decimal] 27 52 <br>
     * [Hexadecimal] 1B 34 <br>
     * [Parameters] None <br>
     * [Description] <br>- Applies the italic character style. <br>
     */
    public void escpApplyItalic() {
        byte[] buffer = { 0x1b, 0x34 };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Cancel Italic Style command in the transmitting buffer. <br><br>
     * The Cancel Italic Style command is as follows: <br><br>
     * ESC 5 Cancel italic style. <br>
     * [ASCII] ESC 5 <br>
     * [Decimal] 27 53 <br>
     * [Hexadecimal] 1B 35 <br>
     * [Parameters] None <br>
     * [Description] <br>- Cancels the italic character style. <br>
     * [Example] <br>
     * Code <br>
     * 
     * <pre>
     *       ABC ESC 4 DEF ESC 5 GHI FF
     * </pre>
     * 
     * Print result <br>
     * 
     * <pre>
     *       ABC<i>DEF</i>GHI
     * </pre>
     */
    public void escpCancelItalic() {
        byte[] buffer = { 0x1b, 0x35 };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Apply Bold Style command in the transmitting buffer. <br><br>
     * The Apply Bold Style command is as follows: <br><br>
     * ESC E Apply bold style. <br>
     * [ASCII] ESC E <br>
     * [Decimal] 27 69 <br>
     * [Hexadecimal] 1B 45 <br>
     * [Parameters] None <br>
     * [Description] <br>- Prints the following print data in bold. <br>-
     * Available at any point in the text line. <br>
     */
    public void escpApplyBold() {
        byte[] buffer = { 0x1b, 0x45 };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Cancel Bold Style command in the transmitting buffer. <br><br>
     * The Cancel Bold Style command is as follows: <br><br>
     * ESC F Cancel bold style. <br>
     * [ASCII] ESC F <br>
     * [Decimal] 27 70 <br>
     * [Hexadecimal] 1B 46 <br>
     * [Parameters] None <br>
     * [Description] <br>- Cancels the bold style. <br>- Available at any
     * point in the text line. <br>
     * [Example] <br>
     * Code <br>
     * 
     * <pre>
     *       ABC ESC E DEF ESC F GHI FF
     * </pre>
     * 
     * Print result <br>
     * 
     * <pre>
     *       ABC<b>DEF</b>GHI
     * </pre>
     */
    public void escpCancelBold() {
        byte[] buffer = { 0x1b, 0x46 };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Specify Double Printing command in the transmitting buffer. <br><br>
     * The Specify Double Printing command is as follows: <br><br>
     * ESC G Specify double printing. <br>
     * [ASCII] ESC G <br>
     * [Decimal] 27 71 <br>
     * [Hexadecimal] 1B 47 <br>
     * [Parameters] None <br>
     * [Description] <br>- Applies the bold style. <br>- Prints the following
     * print data in bold. <br>- Available at any point in the text line. <br>
     */
    public void escpSpecifyDoublePrinting() {
        byte[] buffer = { 0x1b, 0x47 };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Cancel Double Printing command in the transmitting buffer. <br><br>
     * The Cancel Double Printing command is as follows: <br><br>
     * ESC H Cancel double printing. <br>
     * [ASCII] ESC H <br>
     * [Decimal] 27 72 <br>
     * [Hexadecimal] 1B 48 <br>
     * [Parameters] None <br>
     * [Description] <br>- Cancels the bold style. <br>- Available at any
     * point in the text line. <br>
     * [Example] <br>
     * Code <br>
     * 
     * <pre>
     *       ABC ESC E DEF ESC F GHI FF
     * </pre>
     * 
     * Print result <br>
     * 
     * <pre>
     *       ABC<b>DEF</b>GHI
     * </pre>
     */
    public void escpCancelDoublePrinting() {
        byte[] buffer = { 0x1b, 0x48 };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Specify Pica Pitch command in the transmitting buffer. <br><br>
     * The Specify Pica Pitch command is as follows: <br><br>
     * ESC P Specify pica pitch. <br>
     * [ASCII] ESC P <br>
     * [Decimal] 27 80 <br>
     * [Hexadecimal] 1B 50 <br>
     * [Parameters] None <br>
     * [Description] <br>- Prints the following data (ANK characters) with the
     * pica pitch (10 characters/inch). <br>- The spacing per character is 30
     * dots (=300 dots/10 characters). <br>- If the character width is 30 dots
     * or less, the spacing between the characters is set to the value of 30 -
     * the character width. <br>- If the character width is greater than 30
     * dots, the characters are positioned with the character width set as the
     * spacing per character. (The spacing between characters is 0 dot.) In this
     * case, the pitch is not exactly equal to the pica pitch. <br>- With
     * double-width characters, the spacing per character is doubled (60 dots).
     * <br>- With reduced characters, the spacing per character is halved (15
     * dots). <br>- The setting is updated when the character spacing is
     * changed using ESC SP. <br>- This command is not available if the
     * proportional pitch is selected. <br><br>
     * <table border=1>
     * <tr>
     * <th rowspan=2 colspan=2>Setting (dots)</th>
     * <th colspan=3>Full width</th>
     * <th colspan=3>Double width</th>
     * <th colspan=3>Reduced</th>
     * </tr>
     * <th>24</th>
     * <th>32</th>
     * <th>48</th>
     * <th>24</th>
     * <th>32</th>
     * <th>48</th>
     * <th>24</th>
     * <th>32</th>
     * <th>48</th>
     * </tr>
     * <tr>
     * <td rowspan=5>Width (dots)</td>
     * <td>Brougham</td>
     * <td>11</td>
     * <td>16</td>
     * <td>26</td>
     * <td>22</td>
     * <td>32</td>
     * <td>52</td>
     * <td>6</td>
     * <td>8</td>
     * <td>13</td>
     * </tr>
     * <tr>
     * <td>Letter Gothic Bold</td>
     * <td>10</td>
     * <td>14</td>
     * <td>22</td>
     * <td>20</td>
     * <td>28</td>
     * <td>44</td>
     * <td>5</td>
     * <td>7</td>
     * <td>11</td>
     * </tr>
     * <tr>
     * <td>Brussels</td>
     * <td>25</td>
     * <td>35</td>
     * <td>56</td>
     * <td>50</td>
     * <td>70</td>
     * <td>112</td>
     * <td>13</td>
     * <td>18</td>
     * <td>28</td>
     * </tr>
     * <tr>
     * <td>Helsinki</td>
     * <td>21</td>
     * <td>28</td>
     * <td>44</td>
     * <td>42</td>
     * <td>56</td>
     * <td>88</td>
     * <td>11</td>
     * <td>14</td>
     * <td>22</td>
     * </tr>
     * <tr>
     * <td>San Diego</td>
     * <td>24</td>
     * <td>35</td>
     * <td>57</td>
     * <td>48</td>
     * <td>70</td>
     * <td>114</td>
     * <td>12</td>
     * <td>18</td>
     * <td>29</td>
     * </tr>
     * </table><br>
     * The table shown above lists character sizes with a fixed pitch.
     * (Characters may be larger if a style is applied.) <br>
     * <br>
     * [Example] With a width of 24 dots at full width <br>
     * <br>
     * <img src="../../../../../../resources/esc_p.bmp"> <br>
     * <br>
     */
    public void escpSpecifyPicaPitch() {
        byte[] buffer = { 0x1b, 0x50 };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Specify Elite Pitch command in the transmitting buffer. <br><br>
     * The Specify Elite Pitch command is as follows: <br><br>
     * ESC M Specify elite pitch. <br>
     * [ASCII] ESC M <br>
     * [Decimal] 27 77 <br>
     * [Hexadecimal] 1B 4D <br>
     * [Parameters] None <br>
     * [Description] <br>- Prints the following data (ANK characters) with the
     * elite pitch (12 characters/inch). <br>- The spacing per character is 25
     * dots (=300 dots/12 characters). <br>- If the character width is 25 dots
     * or less, the spacing between the characters is set to the value of 25 -
     * the character width. <br>- If the character width is greater than 25
     * dots, the characters are positioned with the character width set as the
     * spacing per character. (The spacing between characters is 0 dot.) In this
     * case, the pitch is not exactly equal to the elite pitch. <br>- With
     * double-width characters, the spacing per character is doubled (50 dots).
     * <br>- With reduced characters, the spacing per character is 13 dots.
     * <br>- The setting is updated when the character spacing is changed using
     * ESC SP. <br>- This command is not available if the proportional pitch is
     * selected. <br>
     * <br>
     * [Example] With a width of 24 dots at full width <br>
     * <br>
     * <img src="../../../../../../resources/esc_m.bmp"> <br>
     * <br>
     */
    public void escpSpecifyElitePitch() {
        byte[] buffer = { 0x1b, 0x4D };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Specify Micron Pitch command in the transmitting buffer. <br><br>
     * The Specify Micron Pitch command is as follows: <br><br>
     * ESC g Specify micron pitch. <br>
     * [ASCII] ESC g <br>
     * [Decimal] 27 103 <br>
     * [Hexadecimal] 1B 67 <br>
     * [Parameters] None <br>
     * [Description] <br>- Prints the following data (ANK characters) with the
     * micron pitch (15 characters/inch). <br>- The spacing per character is 20
     * dots (=300 dots/15 characters). <br>- If the character width is 20 dots
     * or less, the spacing between the characters is set to the value of 20 -
     * the character width. <br>- If the character width is greater than 20
     * dots, the characters are positioned with the character width set as the
     * spacing per character. (The spacing between characters is 0 dot.) In this
     * case, the pitch is not exactly equal to the micron pitch. <br>- With
     * double-width characters, the spacing per character is doubled (40 dots).
     * <br>- With reduced characters, the spacing per character is halved (10
     * dots). <br>- The setting is updated when the character spacing is
     * changed using ESC SP. <br>- This command is not available if the
     * proportional pitch is selected. <br>
     * <br>
     * [Example] With a width of 11 dots at full width <br>
     * <br>
     * <img src="../../../../../../resources/esc_g.bmp"> <br>
     * <br>
     */
    public void escpSpecifyMicronPitch() {
        byte[] buffer = { 0x1b, 0x67 };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Specify Proportional Characters command with the parameter in the
     * transmitting buffer. <br><br>
     * The Specify Proportional Characters command is as follows: <br><br>
     * ESC p Specify proportional characters. <br>
     * [ASCII] ESC p n <br>
     * [Decimal] 27 112 n <br>
     * [Hexadecimal] 1B 70 n <br>
     * [Parameters] n=0, 1, "0", "1" <br>
     * [Description] <br>- Specifies proportional characters. <br>- If n=1 or
     * "1", the proportional characters are applied. <br>- If n=0 or "0",
     * proportional characters are cancelled. <br>- If proportional characters
     * are applied, the character spacing specified using ESC SP is saved as it
     * is. <br>
     * 
     * @param proportional Specifies the proportional characters. Please choose from PROPORTINAL_ fields. 
     */
    public void escpSpecifyProportional(int proportional) {
        if (0 <= proportional && proportional <= 1) {
            byte[] buffer = { 0x1b, 0x70, (byte) proportional };
            mpEscpCommand(buffer);
        }
    }

    /**
     * Stores Specify Double-Width Characters command with the parameter in the
     * transmitting buffer. <br><br>
     * The Specify Double-Width Characters command is as follows: <br><br>
     * ESC W Specify double-width characters. <br>
     * [ASCII] ESC W n <br>
     * [Decimal] 20 87 n <br>
     * [Hexadecimal] 1B 57 n <br>
     * [Parameters] n=0 and 1 or 48 and 49 <br>
     * [Description] <br>- Specifies double-width characters. <br>- If n=1 or
     * 49 ("1"), double width is applied. <br>- If n=0 or 48 ("0"), double
     * width is cancelled. <br>- Double width applied using this code cannot be
     * cancelled using the DC4 code or a line feed. <br>
     * [Example] <br>
     * Code <br>
     * 
     * <pre>
     *       ABC ESC W 1 ABC ESC W 0 ABC FF
     * </pre>
     * 
     * Print result <br>
     * <br>
     * <img src="../../../../../../resources/esc_w.bmp"> <br>
     * <br>
     * 
     * @param doubleWidth Specifies the double-width characters. Please choose from DOUBLE_WIDTH_ fields. 
     */
    public void escpSpecifyDoubleWidth(int doubleWidth) {
        if (0 <= doubleWidth && doubleWidth <= 1) {
            byte[] buffer = { 0x1b, 0x57, (byte) doubleWidth };
            mpEscpCommand(buffer);
        }
    }

    /**
     * Stores Specify Auto-Cancelling Enlarged Characters command in the
     * transmitting buffer. <br><br>
     * The Specify Auto-Cancelling Enlarged Characters command is as follows:
     * <br><br>
     * SO Specify auto-cancelling enlarged characters. <br>
     * [ASCII] SO <br>
     * [Decimal] 14 <br>
     * [Hexadecimal] 0E <br>
     * [Parameters] None <br>
     * [Description] <br>- Prints the following data in double-width
     * characters. <br>- This mode is cancelled using DC4, LF, VT, FF, or an
     * automatic line feed. <br>- This mode can also be cancelled using ESC
     * W+0. <br>
     */
    public void escpSpecifyAutoCancellingEnlarged() {
        byte[] buffer = { 0x0e };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Specify Auto-Cancelling Enlarged Characters command in the
     * transmitting buffer. <br><br>
     * The Specify Auto-Cancelling Enlarged Characters command is as follows:
     * <br><br>
     * ESC SO Specify auto-cancelling enlarged characters. <br>
     * [ASCII] ESC SO <br>
     * [Decimal] 27 14 <br>
     * [Hexadecimal] 1B 0E <br>
     * [Parameters] None <br>
     * [Description] <br>- Same as SO <br>
     * [Example] <br>
     * Code <br>
     * 
     * <pre>
     *       ABC ESC SO ABCDEFGHIJK...XYZ FF
     * </pre>
     * 
     * Print result <br>
     * <br>
     * <img src="../../../../../../resources/esc_so.bmp"> <br>
     * <br>
     */
    public void escpSpecifyAutoCancellingEnlarged2() {
        byte[] buffer = { 0x1b, 0x0e };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Specify Reduced Characters command in the transmitting buffer.
     * <br><br>
     * The Specify Reduced Characters command is as follows: <br><br>
     * SI Specify reduced characters. <br>
     * [ASCII] SI <br>
     * [Decimal] 15 <br>
     * [Hexadecimal] 0F <br>
     * [Parameters] None <br>
     * [Description] <br>- Prints the following data in half-width characters.
     * <br>
     */
    public void escpSpecifyReduced() {
        byte[] buffer = { 0x0f };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Specify Reduced Characters command in the transmitting buffer.
     * <br><br>
     * The Specify Reduced Characters command is as follows: <br><br>
     * ESC SI Specify reduced characters. <br>
     * [ASCII] ESC SI <br>
     * [Decimal] 27 15 <br>
     * [Hexadecimal] 1B 0F <br>
     * [Parameters] None <br>
     * [Description] <br>- Same as SI <br>
     */
    public void escpSpecifyReduced2() {
        byte[] buffer = { 0x1b, 0x0f };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Cancel Reduced Characters command in the transmitting buffer. <br><br>
     * The Cancel Reduced Characters command is as follows: <br><br>
     * DC2 Cancel reduced characters. <br>
     * [ASCII] DC2 <br>
     * [Decimal] 18 <br>
     * [Hexadecimal] 12 <br>
     * [Parameters] None <br>
     * [Description] <br>- Cancels the reduced characters specified using SI.
     * <br>
     */
    public void escpCancelReduced() {
        byte[] buffer = { 0x12 };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Cancel Auto-Cancelling Double-Width Characters command in the
     * transmitting buffer. <br><br>
     * The Cancel Auto-Cancelling Double-Width Characters command is as follows:
     * <br><br>
     * DC4 Cancel auto-cancelling double-width characters. <br>
     * [ASCII] DC4 <br>
     * [Decimal] 20 <br>
     * [Hexadecimal] 14 <br>
     * [Parameters] None <br>
     * [Description] <br>- Cancels the double-width characters specified using
     * ESC SO or SO. <br>- The setting specified using ESC W is not cancelled.
     * <br>
     * [Example] <br>
     * Code <br>
     * 
     * <pre>
     *       ABC ESC SO ABCDEF DC4 GHIJK FF
     * </pre>
     * 
     * Print result <br>
     * <br>
     * <img src="../../../../../../resources/dc4.bmp"> <br>
     * <br>
     */
    public void escpCancelAutoCancellingDoubleWidth() {
        byte[] buffer = { 0x14 };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Apply/Cancel Underlining command with the parameter in the
     * transmitting buffer. <br><br>
     * The Apply/Cancel Underlining command is as follows: <br><br>
     * ESC - Apply/cancel underlining. <br>
     * [ASCII] ESC - n <br>
     * [Decimal] 27 45 n <br>
     * [Hexadecimal] 1B 2D n <br>
     * [Parameters] n=0, 1, 2, 3, 4 <br>
     * [Description] <br>
     * - Applies and cancels underlining. <br>
     * - If n=4, underlining with a width of 4 dots is applied. <br>
     * - If n=3, underlining with a width of 3 dots is applied. <br>
     * - If n=2, underlining with a width of 2 dots is applied. <br>
     * - If n=1, underlining with a width of 1 dot is applied. <br>
     * - If n=0, underlining is cancelled. <br>
     * - Available at any point in the text line. <br>
     * - Underlining specified using this code is a continuous line. <br>
     * - Spaces between characters and words are also underlined. <br>
     * - Areas specified using the "specify absolute horizontal position" (ESC $) and "specify relative horizontal
     * position" (ESC \) commands cannot be underlined. <br>- Bit image data
     * and bar codes are not underlined. <br>- For lines that contain
     * underlined characters, 4/300 inch (4 dots) is added to the specified line
     * feed amount. <br>- With an underline width of 1 dot, the underline is
     * positioned as described below. <br>
     * At a position 2/300 inch (2 dots) below the character <br>- With an
     * underline width of 2 dots, the underline is positioned as described
     * below. <br>
     * At a position 2/300 inch (2 dots) and 3/300 inch (3 dots) below the
     * character <br>- With an underline width of 3 dots, the underline is
     * positioned as described below. <br>
     * At a position between 1/300 inch (1 dot) and 3/300 inch (3 dots) below
     * the character <br>- With an underline width of 4 dots, the underline is
     * positioned as described below. <br>
     * At a position between 1/300 inch (1 dot) and 4/300 inch (4 dots) below
     * the character <br>
     * <br>
     * <img src="../../../../../../resources/esc_-.bmp"> <br>
     * <br>
     * [Example] <br>
     * Code <br>
     * 
     * <pre>
     *       ABC ESC - 1 ABC ESC - 0 ABC FF
     * </pre>
     * 
     * Print result <br>
     * 
     * <pre>
     *       ABC<u>DEF</u>GHI
     * </pre>
     * 
     * @param underlining Specifies the underlining. Please choose from UNDERLINING_ fields. 
     */
    public void escpUnderlining(int underlining) {
        if (0 <= underlining && underlining <= 4) {
            byte[] buffer = { 0x1b, 0x2d, (byte) underlining };
            mpEscpCommand(buffer);
        }
    }

    /**
     * Stores Global Formatting command with the parameter in the transmitting
     * buffer. <br><br>
     * The Global Formatting command is as follows: <br><br>
     * ESC ! Global formatting. <br>
     * [ASCII] ESC ! n <br>
     * [Decimal] 27 33 n <br>
     * [Hexadecimal] 1B 21 n <br>
     * [Parameters] 0 <= n <= 255 <br>
     * [Description] <br>
     * - Specifies a combination of the various print modes.<br>
     * - Specifies the mode according to each bit of the value of n.<br>
     * - Using the ESC ! code, a combination of multiple print modes can be specified at the same time. <br>
     * - Priority is given in order from bit 5 to bit 2.<br>
     * - Bit 0 is available only if bit 1 is "0". <br>
     * <br>
     * [Example] To set underlining and double width at the same time <br>
     * Code <br>
     * 
     * <pre>
     *       ABC ESC ! A0h ABC ESC ! 00h ABC FF
     * </pre>
     * 
     * Print result <br>
     * <br>
     * <img src="../../../../../../resources/esc_ex.bmp"> <br>
     * <br>
     * 
     * @param printModes Specifies a combination of the various print modes. 
     */
    public void escpGrobalFormatting(int printModes) {
        if (0 <= printModes && printModes <= 255) {
            byte[] buffer = { 0x1b, 0x21, (byte) printModes };
            mpEscpCommand(buffer);
        }
    }

    /**
     * Stores Select Character Spacing For ANK Characters command with the
     * parameter in the transmitting buffer. <br><br>
     * The Select Character Spacing For ANK Characters command is as follows:
     * <br><br>
     * ESC SP Select character spacing for ANK characters. <br>
     * [ASCII] ESC SP n <br>
     * [Decimal] 27 32 n <br>
     * [Hexadecimal] 1B 20 n <br>
     * [Parameters] 0 <= n <= 127 <br>
     * [Description] <br>
     * - Specifies the character spacing. <br>
     * - "n" indicates the number of dots. <br>
     * - The default setting is 0 dots. <br>
     * - With the double width setting, the character spacing is doubled, and with
     * the half width setting, the spacing is halved. <br>
     * <br>
     * <img src="../../../../../../resources/esc_sp.bmp"> <br>
     * <br>
     * 
     * @param dots Specifies the character spacing. 
     */
    public void escpSelectSpacing(int dots) {
        if (0 <= dots && dots <= 127) {
            byte[] buffer = { 0x1b, 0x20, (byte) dots };
            mpEscpCommand(buffer);
        }
    }

    /**
     * Stores Select Alphanumeric/Kana Character Size command with the
     * parameters in the transmitting buffer. <br><br>
     * The Select Alphanumeric/Kana Character Size command is as follows: <br><br>
     * ESC X Select alphanumeric/kana character size. <br>
     * [ASCII] ESC X m nL nH <br>
     * [Decimal] 27 88 m nL nH <br>
     * [Hexadecimal] 1C 58 m nL nH <br>
     * [Parameters] Character width: The value of m is irrelevant. <br>
     * Character size: nL = 24, 32, or 48 dots <br>
     * Available only when nH = 0. <br>
     * [Description] <br>
     * - This command is only used to change the size. <br>
     * - Underlining must not be specified. <br>
     * - Character width cannot be specified. <br>
     * - The character size is set to n=nL+nH*256 dots. <br>
     * - The width and the height is the same size. <br>
     * - Only n=24, 32, or 48 are available. <br>
     * - The settings for the "specify enlarged characters",
     * the "specify reduced characters", and the "select alphanumeric/kana
     * character size" commands (SO, ESC W, ESC !, and ESC SP) remain valid, and
     * these commands are also available. <br>
     * [Example] "ABC" in 24 dots and "DEF" in 48 dots <br>
     * Code <br>
     * 
     * <pre>
     *       ESC X 00h 18h 00h ABC
     *       ESC X 00h 30h 00h DEF FF
     * </pre>
     * 
     * Print result <br>
     * 
     * <pre>
     *       <font point-size=12>ABC</font><font point-size=24>DEF</font>
     * </pre>
     * 
     * @param characterSize Specifies the character size as 24, 32, or 48. 
     */
    public void escpSelectSize(int characterSize) {
        byte[] buffer = { 0x1c, 0x58, 0x00, (byte) characterSize, 0x00};
        mpEscpCommand(buffer);
    }
}

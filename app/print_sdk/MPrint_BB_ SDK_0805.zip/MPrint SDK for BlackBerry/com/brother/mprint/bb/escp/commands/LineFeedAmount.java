package com.brother.mprint.bb.escp.commands;

import com.brother.mprint.bb.escp.EscpCommand;

/**
 * Provides ESC/P command for the line feed amount. <br>
 * @author naoki
 */
public class LineFeedAmount extends EscpCommand{

    /**
     * Stores Specify Line Feed Of 1/8" command in the transmitting buffer. <br><br>
     * The Specify Line Feed Of 1/8" command is as follows: <br><br>
     * ESC 0 Specify line feed of 1/8". <br>
     * [ASCII] ESC 0 <br>
     * [Decimal] 27 48 <br>
     * [Hexadecimal] 1B 30 <br>
     * [Parameters] None <br>
     * [Description] <br>- Specifies a line feed amount of 1/8" (approximately
     * 0.32 cm). <br>- Specifies a line feed amount of 38/300" (38 dots). <br>
     */
    public void escpSpecifyLineFeedOfOneEighth() {
        byte[] buffer = { 0x1b, 0x30 };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Specify Line Feed Of 1/6" command in the transmitting buffer. <br><br>
     * The Specify Line Feed Of 1/6" command is as follows: <br><br>
     * ESC 2 Specify line feed of 1/6". <br>
     * [ASCII] ESC 2 <br>
     * [Decimal] 27 50 <br>
     * [Hexadecimal] 1B 32 <br>
     * [Parameters] None <br>
     * [Description] <br>- Specifies a line feed amount of 1/6" (approximately
     * 0.42 cm). <br>- Specified when the unit is turned on. <br>- Specifies a
     * line feed amount of 50/300" (50 dots). <br>
     */
    public void escpSpecifyLineFeedOfOneSixth() {
        byte[] buffer = { 0x1b, 0x32 };
        mpEscpCommand(buffer);
    }

    /**
     * Stores Specify Line Feed Amount In Minimum Units command with the
     * parameter in the transmitting buffer. <br><br>
     * The Specify Line Feed Amount In Minimum Units command is as follows: <br><br>
     * ESC 3 Specify line feed amount in minimum units. <br>
     * [ASCII] ESC 3 n <br>
     * [Decimal] 27 51 n <br>
     * [Hexadecimal] 1B 33 n <br>
     * [Parameters] 0 <= n <= 255 <br>
     * [Description] <br>- Specifies a line feed amount of n/300" per text
     * line. <br>- The line feed should be set in 1-dot units. <br>
     * 
     * @param dots Specifies a line feed amount of n/300" per text line. The line feed should be set in 1-dot units.
     */
    public void escpSpecifyLineFeedAmountInMinimumUnits(int dots) {
        if (0 <= dots && dots <= 255) {
            byte[] buffer = { 0x1b, 0x33, (byte) dots };
            mpEscpCommand(buffer);
        }
    }

    /**
     * Stores Specify Line Feed Amount Of n/60" command with the parameter in
     * the transmitting buffer. <br><br>
     * The Specify Line Feed Amount Of n/60" command is as follows: <br><br>
     * ESC A Specify line feed amount of n/60". <br>
     * [ASCII] ESC A n <br>
     * [Decimal] 27 65 n <br>
     * [Hexadecimal] 1B 41 n <br>
     * [Parameters] 0 <=n <=255 <br>
     * [Description] <br>- Specifies a line feed amount of n/60". <br>- The
     * line feed amount should be set in 5-dot units. <br>
     * 
     * @param fiveDots Specifies a line feed amount of n/60". The line feed amount should be set in 5-dot units.
     */
    public void escpSpecifyLineFeedAmountOfNSixtieth(int fiveDots) {
        if (0 <= fiveDots && fiveDots <= 255) {
            byte[] buffer = { 0x1b, 0x41, (byte) fiveDots };
            mpEscpCommand(buffer);
        }
    }
}
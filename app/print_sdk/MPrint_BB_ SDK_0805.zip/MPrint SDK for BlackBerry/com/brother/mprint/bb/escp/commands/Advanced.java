package com.brother.mprint.bb.escp.commands;

import com.brother.mprint.bb.escp.AdvancedCommon;
import com.brother.mprint.bb.escp.BluetoothConnection;

/**
 * Provides advanced ESC/P command capabilities. <br>
 * @author naoki
 */
public class Advanced extends AdvancedCommon {
    BluetoothConnection bluetoothConnection = BluetoothConnection.getInstance();

    /**
     * Stores the Bar Code command with the parameters in the transmitting
     * buffer. <br><br>
     * The Bar Code command is as follows: <br><br>
     * ESC i B Bar code. <br>
     * [ASCII] ESC i [parameter] B or b [bar code data] backslash <br>
     * [Decimal] 27 105 [parameter] 66 or 98 [bar code data] 92 <br>
     * [Hexadecimal] 1B 69 [parameter] 42 or 62 [bar code data] 5C <br>
     * [Parameters] <br>
     * T or t (type) <br>
     * t0: CODE39 <br>
     * t1: INTERLEAVED 2 OF 5 <br>
     * t5: EAN-8, EAN-13, UPC-A <br>
     * t6: UPC-E <br>
     * t9: CODABAR <br>
     * s (style) Ignored <br>
     * p (number of passes) Ignored <br>
     * R or r (Characters below bar code) <br>
     * r0: OFF <br>
     * r1: ON <br>
     * u (units of measurement) Ignored <br>
     * x (horizontal position) Ignored <br>
     * y (vertical offset) Ignored <br>
     * h (size of height) <br>
     * h n1 n2 <br>
     * Height = n1 + n2 * 256 (dots) <br>
     * 48 <= Height <= 480 <br>
     * If height <48, height=48 <br>
     * If height>480, height=480 <br>
     * w (size of width) <br>
     * w0: extra small <br>
     * w1: small <br>
     * w2: medium <br>
     * w3: large <br>
     * B or b: Beginning of bar code data <br>? (generate checkdigit) <br>
     * Generates a check digit when "?" is in the bar code data <br>
     * The position of "?" is irrelevant as long as it is within the bar code
     * data. <br>
     * <br>
     * Backslash: End of bar code data <br>
     * Both 00H through 09H and 30H through 39H are recognized as the parameter
     * numbers 0 through 9.<br>
     * If there is no type command or if the type command is invalid, Code 39 is
     * used. <br>
     * The number of characters that can be entered for each type is as follows:
     * <br>
     * t0: 2 to 20 characters <br>
     * t1: 3 to 22 characters <br>
     * t5: 7 characters (for EAN-8) <br>
     * 12 characters (for EAN-13) <br>
     * 11 characters (for UPC-A) <br>
     * t6: 6 characters <br>
     * t9: 4 to 22 characters <br>
     * [Description] <br>- Specifies a bar code image. <br>- Data that extends
     * past the right margin is ignored. <br>- Since the check digit is
     * automatically generated from the bar code data, the check digit cannot be
     * sent as the bar code data. <br>
     * If there is check digit data for checking the length of the bar code
     * data, it will not be recognized correctly. <br>
     * 
         * @param barCodeType Specifies the bar code type. Please choose from BAR_CODE_TYPE_ fields. 
         * @param charactersBelowBarCode Specifies to turn the characters below bar code on or off. Please choose from CHARACTERS_BELOW_BAR_CODE_ fields. 
         * @param barCodeSizeOfHeight Specify the height of the bar code. <br>
         * @param barCodeSizeOfWidth Specifies the bar code size of width. Please choose from BAR_CODE_SIZE_OF_WIDTH_ fields. 
         * @param barCodeData Specifies the bar code data. 
         */
        public void escpBarCode(int barCodeType, int charactersBelowBarCode, int barCodeSizeOfHeight, int barCodeSizeOfWidth, int[] barCodeData)
        {
                byte[] buffer = new byte[13 + barCodeData.length];
                buffer[0] = 0x1b;
                buffer[1] = 0x69;
                buffer[2] = 0x74;
                buffer[3] = (byte)barCodeType;
                buffer[4] = 0x52;
                buffer[5] = (byte)charactersBelowBarCode;
                buffer[6] = 0x68;
                buffer[7] = (byte) getnL(barCodeSizeOfHeight);
                buffer[8] = (byte) getnH(barCodeSizeOfHeight);
                buffer[9] = 0x77;
                buffer[10] = (byte) barCodeSizeOfWidth;
                buffer[11] = 0x42;
                for(int i = 0; i < barCodeData.length; i++)
                {
                        buffer[i + 12] = (byte)(barCodeData[i] + 48);
                }
                buffer[barCodeData.length + 12] = 0x5c;
                mpEscpCommand(buffer);
        }

    /**
     * Stores the Print Downloaded Data command with the parameter in the
     * transmitting buffer. <br><br>
     * The Print Downloaded Data command is as follows: <br><br>
     * ESC i F Print downloaded data. <br>
     * [ASCII] ESC i F P n <br>
     * [Decimal] 27 105 70 80 n <br>
     * [Hexadecimal] 1B 69 46 50 n <br>
     * [Parameters] <br>
     * n: Index of file header <br>
     * 0 <= n <= 7 <br>
     * [Description] <br>
     * - Expands downloaded data as image data in the print buffer. <br>
     * - Expands downloaded image data from the print position.<br>
     * - Ignored if there is no image data. <br>
     * <br>
     * <img src="../../../../../../resources/esc_if1.bmp"> <br>
     * <br>- As with text, if all of the data does not fit in the current line,
     * an automatic line feed is performed, and the data is arranged at the
     * beginning of the next line. At that time, any data the does not fit in
     * the print area is deleted. <br>
     * <br>
     * <img src="../../../../../../resources/esc_if2.bmp"> <br>
     * <br>- If the result of pasting the downloaded image extends past the
     * bottom margin position, the data is pasted in after a page feed is
     * performed. However, if the downloaded image is larger than the space
     * between the top and bottom margins, the entire image is ignored. <br>
     * <br>
     * <img src="../../../../../../resources/esc_if3.bmp"> <br>
     * <br>- The maximum size of a single image data is 1180 * 816 or 816 *
     * 1180 <br>- Since the capacity for saving image data on this unit is
     * limited, no more than 8 maximum-sized image data can be saved at the same
     * time. <br>- The image data is saved in a compressed format; however, the
     * size of the storage space is 240 KB. <br>- If the storage capacity is
     * calculated for uncompressed data <br>
     * the size allows for two paper-size (1180 * 816) image data. <br>- Image
     * data that exceeds the size of the paper is treated as an image where the
     * part that does not fit within the paper is deleted. <br>
     * Even with the same image data, the part that would be deleted differs
     * depending on the paper orientation at the time. <br>
     * Example: <br>
     * With a portrait orientation <br>
     * 1180 (height) * 816 (width) to 1180 (height) * 816 (width) (Not deleted)
     * <br>
     * 816 (height) * 1180 (width) to 816 (height) * 816 (width) <br>
     * <br>
     * <img src="../../../../../../resources/esc_if4.bmp"> <br>
     * <br>
     * With a landscape orientation <br>
     * 816 (height) * 1180 (width) to 816 (height) * 1180 (width) (Not deleted)
     * <br>
     * 1180 (height) * 816 (width) to 816 (height) * 816 (width) <br>
     * <br>
     * <img src="../../../../../../resources/esc_if5.bmp"> <br>
     * <br>
     * 
     * @param indexOfFileHeader Specifies the index of file header stored in MPrint. 
     */
    public void escpDownloadedData(int indexOfFileHeader) {
        if (0 <= indexOfFileHeader && indexOfFileHeader <= 7) {
            byte[] buffer = { 0x1b, 0x69, 0x46, 0x50, (byte) indexOfFileHeader };
            mpEscpCommand(buffer);
        }
    }
}

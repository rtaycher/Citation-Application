package com.brother.mprint.bb.escp;

/**
 * Defines the fields for the command mode. <br>
 * @author oyoshida
 */
public interface CommandMode {

	/**
	 * Predefined ESC/P used for the command mode. <br>
	 */
	public static final int COMMAND_MODE_ESC_P = 0;

	/**
	 * Predefined Raster used for the command mode. <br>
	 */
	public static final int COMMAND_MODE_RASTER_GRAPHICS = 1;

}
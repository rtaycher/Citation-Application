package com.brother.mprint.bb.escp;

/**
 * Defines the fields for the bar codes. <br>
 * @author oyoshida
 */
public interface BarCode {

	/**
	 * Predefined CODE39 used for the bar code type. <br>
	 */
	public static final int BAR_CODE_TYPE_CODE39 = 0;

	/**
	 * Predefined INTERLEAVED 2 OF 5 used for the bar code type. <br>
	 */
	public static final int BAR_CODE_TYPE_INTERLEAVED_2_OF_5 = 1;

	/**
	 * Predefined EAN-8, EAN-13, UPC-A used for the bar code type. <br>
	 */
	public static final int BAR_CODE_TYPE_EAN_8_EAN_13_UPC_A = 5;

	/**
	 * Predefined EUPC-E used for the bar code type. <br>
	 */
	public static final int BAR_CODE_TYPE_UPC_E = 6;

	/**
	 * Predefined CODABAR used for the bar code type. <br>
	 */
	public static final int BAR_CODE_TYPE_CODABAR = 9;

	/**
	 * Predefined setting of Off used to print the characters below bar code. <br>
	 */
	public static final int CHARACTERS_BELOW_BAR_CODE_OFF = 0;

	/**
	 * Predefined setting of On used to print the characters below bar code. <br>
	 */
	public static final int CHARACTERS_BELOW_BAR_CODE_ON = 1;

	/**
	 * Predefined Extra Small size used for the bar code size of width. <br>
	 */
	public static final int BAR_CODE_SIZE_OF_WIDTH_EXTRA_SMALL = 0;

	/**
	 * Predefined Small size used for the bar code size of width. <br>
	 */
	public static final int BAR_CODE_SIZE_OF_WIDTH_SMALL = 1;

	/**
	 * Predefined Medium size used for the bar code size of width. <br>
	 */
	public static final int BAR_CODE_SIZE_OF_WIDTH_MEDIUM = 2;

	/**
	 * Predefined Large size used for the bar code size of width. <br>
	 */
	public static final int BAR_CODE_SIZE_OF_WIDTH_LARGE = 3;

}
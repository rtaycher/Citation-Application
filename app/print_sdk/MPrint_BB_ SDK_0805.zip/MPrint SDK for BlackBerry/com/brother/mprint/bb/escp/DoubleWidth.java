package com.brother.mprint.bb.escp;

/**
 * Defines the fields for the double width. <br>
 * @author oyoshida
 */
public interface DoubleWidth {

	/**
	 * Predefined Cancelled used for the double-width characters. <br>
	 */
	public static final int DOUBLE_WIDTH_CANCELLED = 0;

	/**
	 * Predefined Applied used for the double-width characters. <br>
	 */
	public static final int DOUBLE_WIDTH_APPLIED = 1;

}
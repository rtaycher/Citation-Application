package com.brother.mprint.bb.escp;

/**
 * Provides common commands in advanced ESC/P command set. <br>
 * @author naoki
 */
public class AdvancedCommon extends EscpCommand {

    /**
     * Stores the Switch Command Mode command with the parameter in the
     * transmitting buffer. <br><br>
     * The Switch Command Mode command is as follows: <br><br>
     * ESC i a Switch command mode. <br>
     * [ASCII] ESC i a n <br>
     * [Decimal] 27 105 97 n <br>
     * [Hexadecimal] 1B 69 61 n <br>
     * [Parameters] <br>
     * n: Command mode <br>
     * 0=ESC/P <br>
     * Other than 0 = Raster graphics <br>
     * [Description] <br>- Sets to the command mode to ESC/P or PTCBP (raster
     * graphics). <br>- Dynamically switches between the two modes. <br>-
     * Since it is a dynamic command, the mode returns to the one set in the
     * EEPROM when the unit is turned off. <br>
     * 
     * @param commandMode Specifies command mode. Please choose from COMMAND_MODE_ fields. 
     */
    public void escpCommandMode(int commandMode) {
        byte[] buffer = { 0x1b, 0x69, 0x61, (byte) commandMode };
        mpEscpCommand(buffer);
    }

    /**
     * Stores the Request Printer Status command in the transmitting buffer.
     * <br><br>
     * The Request Printer Status command is as follows: <br><br>
     * ESC i S Request printer status. <br>
     * [ASCII] ESC i S <br>
     * [Decimal] 27 105 83 <br>
     * [Hexadecimal] 1B 69 53 <br>
     * [Parameters] None <br>
     * [Description] <br>- Requests the printer status. <br>
     */
    public void escpRequestPrinterStatus() {
        byte[] buffer = { 0x1b, 0x69, 0x53 };
        mpEscpCommand(buffer);
    }

    /**
     * Stores the Select Landscape Orientation command with parameters in the
     * transmitting buffer. <br><br>
     * The Select Landscape Orientation command is as follows: <br><br>
     * ESC i L Select landscape orientation. <br>
     * [ASCII] ESC i L n <br>
     * [Decimal] 27 105 76 n <br>
     * [Hexadecimal] 1B 69 4C n <br>
     * [Parameters] n=0 and 1 or 48 and 49 <br>
     * [Description] <br>- Specifies and cancels the landscape orientation.
     * <br>- If n=1 or 49 ("1"), the landscape orientation is specified. <br>-
     * If n=0 or 48 ("0"), the landscape orientation is cancelled. <br>- This command clears all the texts because this command initializes first and then sets the landscape. <br>- When creating text, be
     * sure to first specify the orientation of the paper using this command.
     * <br>- The landscape setting is cancelled when the unit is turned on.
     * <br>- This setting is not cancelled with the "initialize" command. <br>
     * <br>
     * <img src="../../../../../resources/esc_il.bmp"> <br>
     * <br>
     * 
     * @param orientation Specifies orientation. Please choose from ORIENTATION_ fields. 
     */
    public void escpOrientation(int orientation) {
        if (orientation == 0 || orientation == 1) {
            byte[] buffer = { 0x1b, 0x69, 0x4c, (byte) orientation };
            mpEscpCommand(buffer);
        }
    }
}

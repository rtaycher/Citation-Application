package com.brother.mprint.bb.escp;

/**
 * Defines the fields for the orientation. <br>
 * @author oyoshida
 */
public interface Orientation {

	/**
	 * Predefined Portrait used for the orientation. <br>
	 */
	public static final int ORIENTATION_PORTRAIT = 0;

	/**
	 * Predefined Landscape used for the orientation. <br>
	 */
	public static final int ORIENTATION_LANDSCAPE = 1;

}
package com.brother.mprint.bb.escp.apps;

import java.util.Date;
import java.util.Enumeration;

import javax.microedition.pim.PIM;
import javax.microedition.pim.PIMException;
import javax.microedition.pim.ToDo;
import javax.microedition.pim.ToDoList;

import net.rim.blackberry.api.menuitem.ApplicationMenuItem;
import net.rim.blackberry.api.menuitem.ApplicationMenuItemRepository;
import net.rim.device.api.i18n.DateFormat;
import net.rim.device.api.i18n.SimpleDateFormat;
import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.Dialog;

import com.brother.mprint.bb.escp.CommunicationPort;
import com.brother.mprint.bb.escp.Connection;
import com.brother.mprint.bb.escp.commands.VerticalMovement;
import com.brother.mprint.bb.escp.sdk.BasicPrinting;

/**
 * @author oyoshida
 */
class BBTasksPrint extends UiApplication {
    /**
     * @param args
     */
    public static void main(String[] args) {
        BBTasksPrint theApp = new BBTasksPrint();
        theApp.enterEventDispatcher();
    }

    private BBTasksPrint() {
        addMenu();
    }

    private void addMenu() {
        PrintMenuInTasks myMenuitem = new PrintMenuInTasks(0);
        ApplicationMenuItemRepository.getInstance().addMenuItem(
                ApplicationMenuItemRepository.MENUITEM_TASK_LIST, myMenuitem);
        System.exit(0);
    }
}

/**
 * @author oyoshida
 */

class PrintMenuInTasks extends ApplicationMenuItem {
    VerticalMovement verticalMovement = new VerticalMovement();

    BasicPrinting basicPrinting = BasicPrinting.getInstance();

    ToDoList toDoList;

    Enumeration enumToDoItems;

    /**
     * @param order
     */
    PrintMenuInTasks(int order) {
        super(order);
    }

    public Object run(Object context) {
        toDoList = null;
        enumToDoItems = null;
        try {
            toDoList = (ToDoList) PIM.getInstance().openPIMList(PIM.TODO_LIST,
                    PIM.READ_ONLY);
            enumToDoItems = toDoList.items();
        } catch (PIMException pe) {
        }
        if (!enumToDoItems.hasMoreElements()) {
            Dialog.alert("There are no tasks to print.");
        } else {
            PrintThread printThread = new PrintThread();
            printThread.start();
        }
        return context;
    }

    public String toString() {
        return "Print...";
    }

    /**
     * @author oyoshida
     */
    private class PrintThread extends Thread {

    	SimpleDateFormat dateFormatDateFull;

        SimpleDateFormat dateFormatTimeDefault;

        Date dateCurrentTime;

        long longCurrentTime;

        int intLine;

        boolean booleanFirstLine;

        PrintThread() {
            dateFormatDateFull = new SimpleDateFormat(DateFormat.DATE_FULL);
            dateFormatTimeDefault = new SimpleDateFormat(
                    DateFormat.TIME_DEFAULT);
            dateCurrentTime = new Date();
            longCurrentTime = dateCurrentTime.getTime();
            intLine = 0;
        }

        public void run() {
            if (basicPrinting.mpEscpInit(CommunicationPort.COMMUNICATION_PORT_BLUETOOTH, Connection.orientationSetting)) {
                basicPrinting.mpEscpPositionCtrl(0, 0);
                while (enumToDoItems.hasMoreElements()) {
                    ToDo toDo = (ToDo) enumToDoItems.nextElement();
                    if (toDoList.isSupportedField(ToDo.SUMMARY)) {
                        for (int j = 0; j < toDo.countValues(ToDo.SUMMARY); ++j) {
                            intLine = printEachLine("    Task: ", intLine, toDo
                                    .getString(ToDo.SUMMARY, j));
                        }
                    }
                    if (toDoList
                            .isSupportedField(ToDo.EXTENDED_FIELD_MIN_VALUE + 9)) {
                        for (int j = 0; j < toDo
                                .countValues(ToDo.EXTENDED_FIELD_MIN_VALUE + 9); ++j) {
                            if (toDo.getInt(ToDo.EXTENDED_FIELD_MIN_VALUE + 9,
                                    j) == 0) {
                                intLine = printEachLine("  Status: ", intLine,
                                        "Not Started");
                            } else if (toDo.getInt(
                                    ToDo.EXTENDED_FIELD_MIN_VALUE + 9, j) == 1) {
                                intLine = printEachLine("  Status: ", intLine,
                                        "In Progress");
                            } else if (toDo.getInt(
                                    ToDo.EXTENDED_FIELD_MIN_VALUE + 9, j) == 2) {
                                intLine = printEachLine("  Status: ", intLine,
                                        "Completed");
                            } else if (toDo.getInt(
                                    ToDo.EXTENDED_FIELD_MIN_VALUE + 9, j) == 3) {
                                intLine = printEachLine("  Status: ", intLine,
                                        "Waiting");
                            } else if (toDo.getInt(
                                    ToDo.EXTENDED_FIELD_MIN_VALUE + 9, j) == 4) {
                                intLine = printEachLine("  Status: ", intLine,
                                        "Deferred");
                            } else {
                                intLine = printEachLine("  Status: ", intLine,
                                        "Not Started");
                            }
                        }
                    }
                    if (toDoList.isSupportedField(ToDo.PRIORITY)) {
                        for (int j = 0; j < toDo.countValues(ToDo.PRIORITY); ++j) {
                            if (toDo.getInt(ToDo.PRIORITY, j) == 9) {
                                intLine = printEachLine("Priority: ", intLine,
                                        "Low");
                            } else if (toDo.getInt(ToDo.PRIORITY, j) == 1) {
                                intLine = printEachLine("Priority: ", intLine,
                                        "High");
                            } else {
                                intLine = printEachLine("Priority: ", intLine,
                                        "Normal");
                            }
                        }
                    }
                    if (toDoList.isSupportedField(ToDo.DUE)) {
                        for (int j = 0; j < toDo.countValues(ToDo.DUE); ++j) {
                            intLine = printEachLine("     Due: ", intLine,
                                    dateFormatDateFull.formatLocal(toDo
                                            .getDate(ToDo.DUE, j))
                                            + " "
                                            + dateFormatTimeDefault
                                                    .formatLocal(toDo.getDate(
                                                            ToDo.DUE, j)));
                        }
                    }
                    if (toDoList.isSupportedField(ToDo.NOTE)) {
                        for (int j = 0; j < toDo.countValues(ToDo.NOTE); ++j) {
                            intLine = printEachLine("   Notes: ", intLine, toDo
                                    .getString(ToDo.NOTE, j));
                        }
                    }
                    if (enumToDoItems.hasMoreElements()) {
                        intLine = lineOrPageFeed(intLine);
                    }
                }
                basicPrinting.mpEscpPrint();
            }
            basicPrinting.mpEscpUninit();
        }

        /**
         * @param stringIndexString
         * @param line
         * @param stringAllStrings
         * @return
         */
        private int printEachLine(String stringIndexString, int line,
                String stringAllStrings) {
            if (stringAllStrings != null && stringAllStrings != "") {
                String strLeft = stringAllStrings;
                strLeft = strLeft.replace('\t', ' ');
                strLeft = strLeft.replace('\n', '\r');
                strLeft = strLeft.replace('\f', '\r');
                strLeft = strLeft.replace('\r', '\r');
                strLeft = trimString(strLeft);
                booleanFirstLine = true;
                int intNumberOfSpacer = stringIndexString.length();
                String stringSpacer = new String();
                for (int i = 0; i < intNumberOfSpacer; i++) {
                    stringSpacer = stringSpacer + (" ");
                }
                if (strLeft.length() <= (49 + 1 - intNumberOfSpacer)
                        && strLeft.lastIndexOf('\r') == -1) {
                    basicPrinting.mpEscpFormatCtrl(0, 11, 0);
                    if (booleanFirstLine) {
                        basicPrinting.mpEscpOutChar(stringIndexString);
                        booleanFirstLine = false;
                    } else {
                        basicPrinting.mpEscpOutChar(stringSpacer);
                    }
                    basicPrinting.mpEscpFormatCtrl(0, 3, 0);
                    basicPrinting.mpEscpOutChar(strLeft);
                    line = lineOrPageFeed(line);
                } else {
                    basicPrinting.mpEscpFormatCtrl(0, 11, 0);
                    if (booleanFirstLine) {
                        basicPrinting.mpEscpOutChar(stringIndexString);
                        booleanFirstLine = false;
                    } else {
                        basicPrinting.mpEscpOutChar(stringSpacer);
                    }
                    line = lineOrPageFeed(line);
                    basicPrinting.mpEscpFormatCtrl(0, 3, 0);
                    String strWork = new String();
                    int intLastIndex;
                    int intIndexOfLF;
                    while (strLeft.length() > 49) {
                        strWork = strLeft.substring(0, 49);
                        intLastIndex = 48;
                        intIndexOfLF = strWork.indexOf('\r');
                        if (intIndexOfLF == -1) {
                            int intLastIndexOfSpace = strWork.lastIndexOf(32);
                            if (intLastIndexOfSpace == -1) {
                                basicPrinting.mpEscpOutChar(strLeft.substring(
                                        0, intLastIndex + 1));
                                line = lineOrPageFeed(line);
                                strWork = trimString(strLeft
                                        .substring(intLastIndex + 1));
                            } else {
                                intLastIndex = intLastIndexOfSpace;
                                basicPrinting.mpEscpOutChar(strLeft.substring(
                                        0, intLastIndex));
                                line = lineOrPageFeed(line);
                                strWork = trimString(strLeft
                                        .substring(intLastIndex + 1));
                            }
                        } else if (intIndexOfLF != -1) {
                            intLastIndex = intIndexOfLF;
                            basicPrinting.mpEscpOutChar(strLeft.substring(0,
                                    intLastIndex));
                            line = lineOrPageFeed(line);
                            strWork = trimString(strLeft
                                    .substring(intLastIndex + 1));
                        }
                        strLeft = strWork;
                    }
                    intIndexOfLF = strLeft.indexOf('\r');
                    while (intIndexOfLF != -1) {
                        intLastIndex = intIndexOfLF;
                        basicPrinting.mpEscpOutChar(strLeft.substring(0,
                                intLastIndex));
                        line = lineOrPageFeed(line);
                        strWork = trimString(strLeft
                                .substring(intLastIndex + 1));
                        strLeft = strWork;
                        intIndexOfLF = strLeft.indexOf('\r');
                    }
                    basicPrinting.mpEscpOutChar(trimString(strLeft));
                    line = lineOrPageFeed(line);
                    strLeft = null;
                }
            }
            return line;
        }

        /**
         * @param stringTrimString
         * @return
         */
        private String trimString(String stringTrimString) {
            stringTrimString.trim();
            if (stringTrimString.length() > 2) {
                while (stringTrimString.length() > 2
                        && (stringTrimString.charAt(0) == '\r' || stringTrimString
                                .charAt(0) == ' ')
                        && (stringTrimString.charAt(1) == '\r' || stringTrimString
                                .charAt(1) == ' ')) {
                    if (stringTrimString.charAt(0) == '\r') {
                        if (stringTrimString.charAt(1) == '\r') {
                            stringTrimString = stringTrimString.substring(1);
                        } else if (stringTrimString.charAt(1) == ' ') {
                            stringTrimString = stringTrimString.substring(1);
                        }
                    }
                    if (stringTrimString.charAt(0) == ' ') {
                        if (stringTrimString.charAt(1) == '\r') {
                            stringTrimString = stringTrimString.substring(1);
                        } else if (stringTrimString.charAt(1) == ' ') {
                            stringTrimString = stringTrimString.substring(1);
                        }
                    }
                }
            }
            if (stringTrimString.length() > 1) {
                if (stringTrimString.charAt(0) == '\r') {
                    stringTrimString = stringTrimString.substring(1);
                }
                if (stringTrimString.charAt(0) == ' ') {
                    stringTrimString = stringTrimString.substring(1);
                }
            }
            return stringTrimString;
        }

        /**
         * @param line
         * @return line
         */
        private int lineOrPageFeed(int line) {
            line++;
            if (line == 24) {
                basicPrinting.mpEscpPrint();
                line = 0;
            } else {
                verticalMovement.escpLineFeed();
            }
            return line;
        }
    }
}

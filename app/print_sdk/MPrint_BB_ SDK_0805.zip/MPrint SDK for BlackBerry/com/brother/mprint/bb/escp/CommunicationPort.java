package com.brother.mprint.bb.escp;

/**
 * Defines the fields for the communication port. <br>
 * @author oyoshida
 */
public interface CommunicationPort {

	/**
	 * Predefined Bluetooth used for communication port. <br>
	 */
	public static final int COMMUNICATION_PORT_BLUETOOTH = 4;

}
package com.brother.mprint.bb.escp;

/**
 * Provides methods to send commands directly to the printer. <br>
 * @author naoki
 */
public class EscpCommand {

        /**
         * Output commands directly. <br><br>
         * For example, <br>
         * <pre>
         * byte[] bTabPos = {0x1b, 0x44, 0x04, 0x0e, 0x10, 0x15, 0x18, 0x1a};
         * mpESCP_Command(bTabPos);
         * </pre>
         * 
         * @param command
         *            Represents commands.
         * @return true if it succeed; false otherwise.
         */
        public boolean mpEscpCommand(byte[] command) {
            if (Connection.communicationStatus == CommunicationStatus.COMMUNICATION_STATUS_COMMUNICATED) {
                for (int i = 0; i < command.length; i++) {
                    Connection.txBuf.addElement(new Byte(command[i]));
                }
                return true;
            } else {
                return false;
            }
        }

        /**
         * Get the high byte of the given parameter. 
         * @param value Specify the value to be splitted to nL and nH. 
         * @return nH; If value is more than 1180, -1. 
         */
        public int getnH(int value) {
                int nH = 0;
                if (0 <= value && value <= 255) {
                        nH = 0;
                } else if (256 <= value && value <= 511) {
                        nH = 1;
                } else if (512 <= value && value <= 767) {
                        nH = 2;
                } else if (768 <= value && value <= 1023) {
                        nH = 3;
                } else if (1024 <= value && value <= 1180) {
                        nH = 4;
                } else {
                        return -1;
                }
                return nH;
        }

        /**
         * Get the low byte of the given parameter. 
         * @param value Specify the value to be splitted to nL and nH. 
         * @return nL; If value is more than 1180, -1. 
         */
        public int getnL(int value) {
                int nL = 0;
                if (0 <= value && value <= 255) {
                        nL = value;
                } else if (256 <= value && value <= 511) {
                        nL = value - 256;
                } else if (512 <= value && value <= 767) {
                        nL = value - 512;
                } else if (768 <= value && value <= 1023) {
                        nL = value - 768;
                } else if (1024 <= value && value <= 1180) {
                        nL = value - 1024;
                } else {
                        return -1;
                }
                return nL;
        }
}

package com.brother.mprint.bb.escp;

/**
 * Defines the fields for the character code table. <br>
 * @author oyoshida
 */
public interface CharacterCodeTable {

	/**
	 * Predefined regular characters used for the character code table. <br>
	 */
	public static final int CHARACTER_CODE_TABLE_REGULAR_CHARACTERS = 0;

	/**
	 * Predefined Eastern European characters used for the character code table. <br>
	 */
	public static final int CHARACTER_CODE_TABLE_EASTERN_EUROPEAN_CHARACTERS = 1;

	/**
	 * Predefined Western European characters used for the character code table. <br>
	 */
	public static final int CHARACTER_CODE_TABLE_WESTERN_EUROPEAN_CHARACTERS = 2;

	/**
	 * Predefined Spare used for the character code table. <br>
	 */
	public static final int CHARACTER_CODE_TABLE_SPARE = 3;

}
package com.brother.mprint.bb.escp;

/**
 * Provides common ESC/P commands the for printer control. <br>
 * @author naoki
 */
public class PrinterControlCommon extends EscpCommand {

	/**
	 * Stores Initialize command in the transmitting buffer. <br><br>
	 * The Initialize command is as follows: <br><br>
	 * ESC@ Initialize. <br>
	 * [ASCII] ESC@ <br>
	 * [Decimal] 27 64 <br>
	 * [Hexadecimal] 1B 40 <br>
	 * [Parameters] None <br>
	 * [Description] <br>- Resets all commands to their default settings. <br>-
	 * Clears the data from the print buffer. <br>- Downloaded data is not
	 * cleared. <br>- The landscape setting is not cleared. <br><br>
	 * <table border=1>
	 * <tr>
	 * <th>Item</th>
	 * <th>Initial Setting</th>
	 * </tr>
	 * <tr>
	 * <td>Input buffer</td>
	 * <td>Saved</td>
	 * </tr>
	 * <tr>
	 * <td>Text buffer</td>
	 * <td>Cleared</td>
	 * </tr>
	 * <tr>
	 * <td>Print buffer</td>
	 * <td>Cleared</td>
	 * </tr>
	 * <tr>
	 * <td>Top margin</td>
	 * <td>0</td>
	 * </tr>
	 * <tr>
	 * <td rowspan=2>Bottom margin</td>
	 * <td>Portrait: 1180</td>
	 * </tr>
	 * <tr>
	 * <td>Landscape: 816</td>
	 * </tr>
	 * <tr>
	 * <td rowspan=2>Right margin</td>
	 * <td>Portrait: 816</td>
	 * </tr>
	 * <tr>
	 * <td>Landscape: 1180</td>
	 * </tr>
	 * <tr>
	 * <td>Left margin</td>
	 * <td>0</td>
	 * </tr>
	 * <tr>
	 * <td>Line feed amount</td>
	 * <td>48 dots</td>
	 * </tr>
	 * <tr>
	 * <td>Horizontal tab positions</td>
	 * <td>Horizontal tabs at every 8 characters <br>
	 * (based on a character width of 10 cpi)</td>
	 * </tr>
	 * <tr>
	 * <td>Vertical tab positions</td>
	 * <td>Not specified</td>
	 * </tr>
	 * <tr>
	 * <td>ANK character pitch</td>
	 * <td>18.75 characters/inch (16 dots)</td>
	 * </tr>
	 * <tr>
	 * <td>ANK character spacing</td>
	 * <td>0 dot</td>
	 * </tr>
	 * <tr>
	 * <td>Font</td>
	 * <td>Brougham</td>
	 * </tr>
	 * <tr>
	 * <td>Character size</td>
	 * <td>32 dots</td>
	 * </tr>
	 * <tr>
	 * <td>International character set</td>
	 * <td>USA</td>
	 * </tr>
	 * <tr>
	 * <td>ANK character style</td>
	 * <td>Cancelled</td>
	 * </tr>
	 * <tr>
	 * <td>Reduced</td>
	 * <td>Cancelled</td>
	 * </tr>
	 * <tr>
	 * <td>Style</td>
	 * <td>Cancelled</td>
	 * </tr>
	 * <tr>
	 * <td>Horizontal print position</td>
	 * <td>Top margin position (TOF position)</td>
	 * </tr>
	 * <tr>
	 * <td>Vertical print position</td>
	 * <td>Left margin position</td>
	 * </tr>
	 * </table>
	 */
	public void escpInitialize() {
		byte[] buffer = { 0x1b, 0x40 };
        mpEscpCommand(buffer);
	}
}
package com.brother.mprint.bb.escp;

/**
 * Defines the fields for the font. <br>
 * @author oyoshida
 */
public interface Font {

	/**
	 * Predefined Brougham used for the font. <br>
	 */
	public static final int FONT_BROUGHAM = 0;

	/**
	 * Predefined Letter Gothic Bold used for the font. <br>
	 */
	public static final int FONT_LETTER_GOTHIC_BOLD = 1;

	/**
	 * Predefined Brussels used for the font. <br>
	 */
	public static final int FONT_BRUSSELS = 2;

	/**
	 * Predefined Helsinki used for the font. <br>
	 */
	public static final int FONT_HELSINKI = 3;

	/**
	 * Predefined San Diego used for the font. <br>
	 */
	public static final int FONT_SAN_DIEGO = 4;

}
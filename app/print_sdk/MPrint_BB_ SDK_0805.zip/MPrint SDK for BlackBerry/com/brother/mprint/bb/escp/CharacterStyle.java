package com.brother.mprint.bb.escp;

/**
 * Defines the fields for the character style. <br>
 * @author oyoshida
 */
public interface CharacterStyle {

	/**
	 * Predefined Cancel used for the character style. <br>
	 */
	public static final int CHARACTER_STYLE_CANCEL = 0;

	/**
	 * Predefined Outline used for the character style. <br>
	 */
	public static final int CHARACTER_STYLE_OUTLINE = 1;

	/**
	 * Predefined Shadow used for the character style. <br>
	 */
	public static final int CHARACTER_STYLE_SHADOW = 2;

	/**
	 * Predefined Shadow and Outline used for the character style. <br>
	 */
	public static final int CHARACTER_STYLE_SHADOW_AND_OUTLINE = 3;

}